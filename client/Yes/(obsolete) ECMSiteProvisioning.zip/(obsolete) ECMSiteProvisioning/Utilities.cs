﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECMSiteProvisioning
{
    class Utilities
    {
        static Dictionary<String, String> siteTemplateMappings;
        static Utilities()
        {
            siteTemplateMappings = new Dictionary<String, String>();
            siteTemplateMappings.Add("Team Site", "GROUP#0");
            siteTemplateMappings.Add("Blog", "BLOG#0");
            siteTemplateMappings.Add("Developer Site", "DEV#0");
            siteTemplateMappings.Add("ECM Template", "{6298C784-F13B-4E96-B29A-B6730A5A0858}#ECM Template");
            siteTemplateMappings.Add("ECMS_Site", "{BCB815C9-B8D3-496A-9D5B-67B184448D52}#ECMS_Site");
        }
        public static String LookupSiteTemplate(String templateName)
        {
            if (siteTemplateMappings.ContainsKey(templateName))
            {
                return siteTemplateMappings[templateName];
            }
            else
            {
                throw new ArgumentException("The template name provided does not have a mapping.", "templateName");
            }
        }

        public static String GenerateSiteUrl(String hostname, String siteTitle)
        {
            var siteUrlTail = siteTitle.Replace(" ", String.Empty).ToLower();
            return String.Format("{0}sites/{1}", hostname, siteUrlTail);
        }
    }
}
