﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECMSiteProvisioning
{
    class Provision
    {
        public void getSiteTemplate(ClientContext clientContext)
        {            
                WebTemplateCollection oWebtTemplateCollection = clientContext.Web.GetAvailableWebTemplates(1033, false);
                clientContext.Load(oWebtTemplateCollection);

                clientContext.ExecuteQuery();

                foreach (WebTemplate oWebTemplate in oWebtTemplateCollection)
                {
                    Console.WriteLine("Template Name: " + oWebTemplate.Name + "  | Template Title: " + oWebTemplate.Title);
                }
        }

        public bool CheckSiteExist(ClientContext tenantContext)
        {
                var web = tenantContext.Web;
                tenantContext.Load(web);

                try
                {
                    tenantContext.ExecuteQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    //sConsole.WriteLine(ex.Message);
                    return false;
                }            
        }

        public void CreateSubSitewithCustomTemplate(ClientContext clientContext, String SubSiteURL, String SubSiteName, String template)
        {            
                WebCreationInformation oWebCreationInformation = new WebCreationInformation();
                // This is relative URL of the url provided in context
                oWebCreationInformation.Url = SubSiteURL;
                oWebCreationInformation.Title = SubSiteName;
                oWebCreationInformation.Description = SubSiteName;

                // This will inherit permission from parent site
                oWebCreationInformation.UseSamePermissionsAsParentSite = true;

                // "STS#0" is the code for 'Team Site' template
                oWebCreationInformation.WebTemplate = template;
                oWebCreationInformation.Language = 1033;

                Web oWeb = clientContext.Site.RootWeb.Webs.Add(oWebCreationInformation);
                oWeb.Navigation.UseShared = true;
                clientContext.ExecuteQuery();
        }

        public string getSiteTemplateCode(ClientContext clientContext, String templateName)
        {
            string siteTemplateCode = "";

            
                WebTemplateCollection oWebtTemplateCollection = clientContext.Web.GetAvailableWebTemplates(1033, false);
                clientContext.Load(oWebtTemplateCollection);

                clientContext.ExecuteQuery();

                foreach (WebTemplate oWebTemplate in oWebtTemplateCollection)
                {
                    //Console.WriteLine("Template Name: " + oWebTemplate.Name + "  | Template Title: " + oWebTemplate.Title);
                    if (oWebTemplate.Title == templateName)
                    {
                        siteTemplateCode = oWebTemplate.Name;
                    }
                }
            

            return siteTemplateCode;
        }
    }
}
