﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using OfficeDevPnP.Core;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using AuthenticationManager = OfficeDevPnP.Core.AuthenticationManager;
using System.IO;

namespace ECMSiteProvisioning
{
    class Program
    {
        static Provision provisioningManager;
        static async Task Main(string[] args)
        {
            Initialize();

            //var siteURL = ConfigurationManager.AppSettings["recordCenterURL"];            

            var reader = new StreamReader(System.IO.File.OpenRead(@"C:\Bkp\ECMSiteProv.csv"));

            List<string> listSiteCol = new List<string>();
            List<string> listSubSite = new List<string>();

            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();

                if (line.Contains("Site Col"))
                {
                    listSiteCol.Add(line);
                }
                if (line.Contains("Sub Site"))
                {
                    listSubSite.Add(line);
                }
            }

            reader.Close();
            reader.Dispose();

            if (listSubSite.Count > 0)
            {
                Console.WriteLine("Sub Site creation started");

                foreach (var subSite in listSubSite)
                {
                    //   if (subSite.Contains(siteParent))
                    //    {
                    String[] val = subSite.Split(',');
                    var siteParent = val[3].ToString();
                    var siteURL = ConfigurationManager.AppSettings["tenantURL"];
                    var siteColURL = Utilities.GenerateSiteUrl(siteURL, siteParent);

                    String[] sub = subSite.Split(',');
                    var subSiteURL = sub[1];
                    var subSiteName = sub[2];
                    var subSiteFullURL = siteColURL + "/" + subSiteURL;

                    var token = await TokenProvider.GetAccessTokenAsync(new Uri(siteColURL).GetLeftPart(UriPartial.Authority));

                    using var contextSubSiteFullURL = new ClientContext(subSiteFullURL);
                    contextSubSiteFullURL.ExecutingWebRequest += (sender, e) =>
                    {
                        e.WebRequestExecutor.RequestHeaders["Authorization"] = "Bearer " + token;
                    };

                    if (provisioningManager.CheckSiteExist(contextSubSiteFullURL) == false)
                    {
                        Console.WriteLine("Sub Site creation started - Name : " + sub[1] + ", URL : " + subSiteFullURL);

                        String templateTitle = sub[4].ToString();

                        using var contextSiteColURL = new ClientContext(siteColURL);
                        contextSiteColURL.ExecutingWebRequest += (sender, e) =>
                        {
                            e.WebRequestExecutor.RequestHeaders["Authorization"] = "Bearer " + token;
                        };

                        String templateName = provisioningManager.getSiteTemplateCode(contextSiteColURL, templateTitle);

                        provisioningManager.CreateSubSitewithCustomTemplate(contextSiteColURL, subSiteURL, subSiteName, templateName);
                        //provisioningManager.CreateSubSitewithCustomTemplate(contextSiteColURL, subSiteURL, subSiteName, "GROUP#0");

                        Console.WriteLine("Sub Site creation completed - Name : " + sub[1] + ", URL : " + subSiteFullURL);
                    }
                    else
                    {
                        Console.WriteLine(subSiteURL + " - Site URL is already exist!");
                    }
                }
            }
            else
            {
                Console.WriteLine("List is empty");
            }

            Console.Read();
        }

        private static void Initialize()
        {
            provisioningManager = new Provision();
        }
    }
}
