﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ECM_AzFnDeclareRecord
{
    public class QueueMessagePL
    {
       
            public string ItemID { get; set; }
            public string ListName { get; set; }
            public string DocumentSourceURLs { get; set; }
            public string SiteURL { get; set; }
        



    }
}
