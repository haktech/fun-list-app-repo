using System;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Client;
using Microsoft.SharePoint.Client;
using System.Linq;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace AzFnDeclareRecordTest
{
    public static class AzFncCreateRCLibQT
    {
        public static string ecmURL = "";
        public static string configListName = "";
        public static string requestCenterURL = "";
        public static string sysRCListName = "";
        public static string requestListName = "";
        public static string itemNumber = "";
        public static string strRecordCenter = "";
        public static string strSiteCollName = "";
        public static string strLibName = "";
        public static string strRCDestURL = "";

        [FunctionName("AzFncCreateRCLibQT")]
        public static async Task Run([QueueTrigger("rc-request-item-no", Connection = "AzureWebJobsStorage")]string myQueueItem, ILogger log,ExecutionContext _context)
        {

            InitVariables();
            var newconfiguration = new ConfigurationBuilder()
               .SetBasePath(_context.FunctionAppDirectory)
               .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
               .AddEnvironmentVariables()
               .Build();
            // var token = await TokenProvider.GetAccessTokenAsync(new Uri(ecmURL).GetLeftPart(UriPartial.Authority));
            var objAzFncPL = new AzFncPL();
            var clientId = Environment.GetEnvironmentVariable("ClientID");
            var tenantId = Environment.GetEnvironmentVariable("TenantID");
            var certThumbPrint = Environment.GetEnvironmentVariable("CertThumbPrint");
            objAzFncPL.clientID = clientId;
            objAzFncPL.tenantID = tenantId;
            objAzFncPL.CertThumbPrint = certThumbPrint;
            string token = await getAuthendicatedToken(objAzFncPL);

            string[] strQueVal = myQueueItem.Split('|');
            requestCenterURL = strQueVal[0];
            requestListName = strQueVal[1];
            itemNumber = strQueVal[2];

            var context = new ClientContext(requestCenterURL);
            context.ExecutingWebRequest += (sender, e) =>
            {
                e.WebRequestExecutor.RequestHeaders["Authorization"] = "Bearer " + token;
            };

            //log.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");

            //  ExecutePromoteToRecordRequests(context, _context);
           
            GetRCRequestURL(context, _context);
            log.LogInformation($"C# Queue trigger function processed: {myQueueItem}");

          //  queueOutput = myQueueItem;
        }
        private static void InitVariables()
        {
            ecmURL = Environment.GetEnvironmentVariable("EcmURL");
            configListName = Environment.GetEnvironmentVariable("configListName");
            strRecordCenter = Environment.GetEnvironmentVariable("RecordCenter");
        }
        public static async Task<string> getAuthendicatedToken(AzFncPL objAzFncPL)
        {

            var scopes = new string[] { "https://brettobe.sharepoint.com/.default" };
            var accessToken = await GetAppAuthedicatedClient(objAzFncPL.clientID, objAzFncPL.CertThumbPrint, scopes, objAzFncPL.tenantID);

            // var accessToken = await GetAppAuthedicatedClient("56755962-d144-4273-81e9-193599ca1aa3", "2E9454F4668A3D17A121583BD6566EC5FFC0EE5A", scopes, "1f4fcefa-f4c6-435d-8dbc-41b312d74871");
            //
            return accessToken;
        }
        internal static async Task<string> GetAppAuthedicatedClient(string clientID, string thumbPrint, string[] scopes, string tenantID)
        {
            X509Certificate2 cert = getAppOnlyCert(thumbPrint);
            IConfidentialClientApplication clientApp = ConfidentialClientApplicationBuilder
                .Create(clientID)
                .WithCertificate(cert)
                .WithTenantId(tenantID)
                .Build();
            AuthenticationResult authResult = await clientApp.AcquireTokenForClient(scopes).ExecuteAsync();
            string strAccessToken = authResult.AccessToken;
            return strAccessToken;
        }
        private static X509Certificate2 getAppOnlyCert(string strThumbPrint)
        {
            X509Certificate2 appOnlyCert = null;
            using (X509Store certStore = new X509Store(StoreName.My, StoreLocation.CurrentUser))
            {
                certStore.Open(OpenFlags.ReadOnly);
                X509Certificate2Collection certCollection = certStore.Certificates.Find(X509FindType.FindByThumbprint, strThumbPrint, false);
                if (certCollection.Count > 0)
                {
                    appOnlyCert = certCollection[0];
                }
                certStore.Close();
                return appOnlyCert;
            }
        }
        public static void GetRCRequestURL(ClientContext clientContext, ExecutionContext _context)
        {
            try
            {
                var newconfiguration = new ConfigurationBuilder()
               .SetBasePath(_context.FunctionAppDirectory)
               .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
               .AddEnvironmentVariables()
               .Build();

                //  ClientContext rcDocContext = null;
                Web oWebsite = clientContext.Web;
                clientContext.Load(oWebsite);
                clientContext.ExecuteQuery();
                Console.WriteLine("rc source url: " + oWebsite.Url);
                var sysRCSitesList = clientContext.Web.Lists.GetByTitle(requestListName);

                clientContext.Load(sysRCSitesList);
                clientContext.ExecuteQuery();

                var rcItems = sysRCSitesList.GetItemById(itemNumber);//.GetItems(CamlQuery.CreateAllItemsQuery());
                clientContext.Load(rcItems);
                clientContext.ExecuteQuery();

                if (rcItems!=null)
                {
                    var list = new List<QueueMessagePL>();
                    var documentURL = Convert.ToString(rcItems["DocumentSourceURLs"]);
                    Console.WriteLine("");
                        Console.WriteLine("Document URL: " + documentURL);

                        if (!string.IsNullOrWhiteSpace(documentURL))
                        {

                        strSiteCollName= GetRecordCenterSiteCollName(documentURL);
                        strLibName = GetRecordCenterLibName(documentURL);
                        
                        string strSiteCllURL = GetRootSitePath(oWebsite.Url);
                        strRCDestURL = $"{strSiteCllURL}/sites/{strSiteCollName}/{strRecordCenter}";
                        // clientContext.Clone()
                        // var context = new ClientContext(ecmURL);
                        // string token = await getAuthendicatedToken(objAzFncPL);
                        //var context = new ClientContext(ecmURL);
                        //context.ExecutingWebRequest += (sender, e) =>
                        //{
                        //    e.WebRequestExecutor.RequestHeaders["Authorization"] = "Bearer " + token;
                        //};
                        // using (var rcContext = new ClientContext(recordCenterURL))
                        using (var rcContext = clientContext.Clone(strRCDestURL))
                            {

                            createRecordCenterLibrary(rcContext, strLibName);
                            Web oWebsite1 = rcContext.Web;
                            rcContext.Load(oWebsite1);
                            rcContext.ExecuteQuery();
                            Console.WriteLine("rc dest url: " + oWebsite1.Url);


                        }

                        list.Add(new QueueMessagePL()
                        {
                            SiteURL = oWebsite.Url.Trim(),
                            ItemID = itemNumber.Trim(),
                            ListName = requestListName,
                            DocumentSourceURLs = documentURL
                        });

                    }
                    SendMessageToQueue(list);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
       

        private static string GetRecordCenterSiteCollName(string documentsPromoted)
        {
            string[] siteCollName = documentsPromoted.Replace("/sites/", "").Split('/');
            return Convert.ToString(siteCollName[0]);
        }


        private static string GetRecordCenterLibName(string documentsPromoted)
        {
            string[] siteCollName = documentsPromoted.Replace("/sites/", "").Split('/');
            return Convert.ToString(siteCollName[1]);
        }

        private static string GetRootSitePath(string webURL)
        {
          //  string[] temp = webURL.Split('/');

            //string startUrl = tenantURL + "/sites";
            string recordCenterSiteLibrary = "";
           // string tempUrl = "https://" + temp[0];
            //<!-- Britto 2022-02-16 >
            // string tempUrl = rcURL + "/" + temp[0];
            // string tempUrl = string.Concat( documentsPromoted,"/","");
            //< Britto 2022-02-16 --!>

            if (webURL.Contains("Confidential") == false)
            {
                string[] library = webURL.Split('/');
                var newLibraryPath = "";

                foreach (string i in library)
                {
                    if (!string.IsNullOrEmpty(i))
                    { 
                    if (i == "sites")
                    {
                        break;
                    }
                    if (i == "https:")
                    {

                        newLibraryPath = newLibraryPath+ $"{i}//";
                    }
                    else
                    newLibraryPath = newLibraryPath + $"{i}";
                    }
                }

                if (newLibraryPath != "")
                {
                    // Fix created library url - remove '-'
                    //newLibraryPath = newLibraryPath.Replace("-", "");

                    //tempUrl = tempUrl + "/" + newLibraryPath;
                    recordCenterSiteLibrary = newLibraryPath;
                }
            }

            return recordCenterSiteLibrary;
        }



        private static void createRecordCenterLibrary(ClientContext clientContext, string documentsPromoted)
        {
            //    var recordCenterLibraryURL = "";
            Console.WriteLine("Creating library - " + documentsPromoted);


           
                try
                {
                   
                var title = documentsPromoted;
                if(!IsLibExist(clientContext, title))
                { 
                    ListCreationInformation creationInfo = new ListCreationInformation();
                    creationInfo.Title = title;
                    creationInfo.Description = title;
                    creationInfo.TemplateType = (int)ListTemplateType.DocumentLibrary;

                    List newList = clientContext.Web.Lists.Add(creationInfo);
                    clientContext.Load(newList);
                    clientContext.ExecuteQuery();


                DeleteExistingContentType(clientContext, title);

                AddContentType(clientContext, title);

                AddViewColumn(clientContext, title);
                }
            }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
           


        }
        private static bool IsLibExist(ClientContext clientContext, string strLibName)
        {
            bool isLibexist = false;
            var lists_ = clientContext.LoadQuery(
                clientContext.Web.Lists.Where(
                    l => l.RootFolder.Name == strLibName));

            clientContext.ExecuteQuery();
             
            if(lists_.Count() >0)
            {
                isLibexist = true;
            }
            return isLibexist;
        }
        private static void DeleteExistingContentType(ClientContext clientContext, string title)
        {
            using (clientContext)
            {
                List TargetList = null;

                // clientcontext.Web.Lists.GetById - This option also can be used to get the list using List GUID
                // This value is NOT List internal name
                TargetList = clientContext.Web.Lists.GetByTitle(title);
                clientContext.Load(TargetList);

                // Load List conntent types
                clientContext.Load(TargetList.ContentTypes);
                clientContext.ExecuteQuery();

                // Write Content Type name over here
                string contentTypeName = "Document";

                // Get list content types
                ContentTypeCollection contentTypeCollection = TargetList.ContentTypes;

                // Get target content type from list content types
                ContentType targetContentType = (from contentType in contentTypeCollection where contentType.Name == contentTypeName select contentType).FirstOrDefault();

                // Condition to delete target content type.
                if (targetContentType != null)
                {
                    targetContentType.DeleteObject();
                    TargetList.Update();
                    clientContext.ExecuteQuery();
                }
            }
        }

        private static void AddContentType(ClientContext clientContext, string title)
        {
            using (clientContext)
            {
                ContentTypeCollection contentTypeCollection;

                // Option - 1 - Get Content Types from Root web
                contentTypeCollection = clientContext.Site.RootWeb.ContentTypes;

                // Option - 2 - Get Content Types from Current web
                //contentTypeCollection = clientContext.Web.ContentTypes;

                clientContext.Load(contentTypeCollection);
                clientContext.ExecuteQuery();

                // Get the content type from content type collection. Give the content type name over here
                ContentType targetContentType = (from contentType in contentTypeCollection where contentType.Name == "PETRONAS Record" select contentType).FirstOrDefault();

                // Add existing content type on target list. Give target list name over here.
                List targetList = clientContext.Web.Lists.GetByTitle(title);
                targetList.ContentTypes.AddExistingContentType(targetContentType);
                targetList.Update();
                clientContext.Web.Update();
                clientContext.ExecuteQuery();
            }
        }

        private static void AddViewColumn(ClientContext clientContext, string title)
        {
            using (clientContext)
            {
                // clientcontext.Web.Lists.GetById - This option also can be used to get the list using List GUID
                // This value is NOT List internal name
                List targetList = clientContext.Web.Lists.GetByTitle(title);

                // Get required view by specifying view Title here
                View targetView = targetList.Views.GetByTitle("All Documents");

                // Add View column. You can specify Internal or display name of the column over here
                targetView.ViewFields.Add("Approver");
                targetView.ViewFields.Add("Business Metadata");
                targetView.ViewFields.Add("Discipline Metadata");
                //targetView.ViewFields.Add("Declared Record");
                targetView.ViewFields.Add("ECMS Record Type");

                targetView.Update();
                clientContext.ExecuteQuery();
            }
        }



        private static string GetRecordCenterLibName1(string documentsPromoted, string rcURL)
        {
            string[] temp = documentsPromoted.Split('/');

            //string startUrl = tenantURL + "/sites";
            string recordCenterSiteLibrary = "";
            string tempUrl = rcURL + "/" + temp[0];
            //<!-- Britto 2022-02-16 >
            // string tempUrl = rcURL + "/" + temp[0];
            // string tempUrl = string.Concat( documentsPromoted,"/","");
            //< Britto 2022-02-16 --!>

            if (documentsPromoted.Contains("Confidential") == false)
            {
                string[] library = documentsPromoted.Replace("/sites/" + temp[0] + "/", "").Split('/');
                var newLibraryPath = "";

                foreach (string i in library)
                {
                    if (i == "Correspondence")
                    {
                        break;
                    }
                    if (i == "Administrative")
                    {
                        break;
                    }
                    if (i == "Governance")
                    {
                        break;
                    }
                    if (i == "Reference")
                    {
                        break;
                    }
                    if (i == "Digital Assets")
                    {
                        break;
                    }

                    newLibraryPath += i;
                }

                if (newLibraryPath != "")
                {
                    // Fix created library url - remove '-'
                    //newLibraryPath = newLibraryPath.Replace("-", "");

                    tempUrl = tempUrl + "/" + newLibraryPath;
                    recordCenterSiteLibrary = tempUrl;
                }
            }

            return recordCenterSiteLibrary;
        }


        private static void SendMessageToQueue(List<QueueMessagePL> list)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(Environment.GetEnvironmentVariable("AzureWebJobsStorage"));
            //StorageConnectionString

            // Create the queue client.  
            CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();

            // Retrieve queue reference from the container  
            CloudQueue queue = queueClient.GetQueueReference("rc-request-movedoc");

            // Create queue if it does not exist  
            queue.CreateIfNotExistsAsync();
            //Create message   
            //CloudQueueMessage message = new CloudQueueMessage(web.Title);
            CloudQueueMessage message = new CloudQueueMessage(JsonConvert.SerializeObject(list));

            //Add message to queue  
            queue.AddMessageAsync(message);
        }
    }
}
