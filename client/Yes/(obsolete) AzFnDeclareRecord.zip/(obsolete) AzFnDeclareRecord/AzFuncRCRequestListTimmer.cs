using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Client;
using Microsoft.SharePoint.Client;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using Newtonsoft.Json;

namespace ECM_AzFnDeclareRecord
{
    public static class AzFuncRCRequestListTimmer
    {
        public static string ecmURL = "";
        public static string configListName = "";
        public static string recordCenterURL = "";
        public static string sysRCListName = "";
        public static string requestListName = "";
        public static string camlquery_str = @"
                                            <View><Query>
                                            <Where>
                                            <Eq>
                                            <FieldRef Name='RecordStatus' />
                                            <Value Type = 'Choice' >Approved</Value>
                                            </Eq>
                                            </Where>
                                            </Query></View>";
        public static string strSysLogTracker = "";
        public static bool IsSandBoxTest = false;
      public static  ILogger log;
        [FunctionName("AzFuncRCRequestListTimmer")]
        public static async Task Run([TimerTrigger("0 */5  * * * *")]TimerInfo myTimer, ILogger log, ExecutionContext _context)
        {
            //[TimerTrigger("0 */2 * * * *")
            InitVariables();
            var newconfiguration = new ConfigurationBuilder()
               .SetBasePath(_context.FunctionAppDirectory)
               .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
               .AddEnvironmentVariables()
               .Build();
            // var token = await TokenProvider.GetAccessTokenAsync(new Uri(ecmURL).GetLeftPart(UriPartial.Authority));
            var objAzFncPL = new AzFncPL();
            var clientId = Environment.GetEnvironmentVariable("clientID");
            var tenantId = Environment.GetEnvironmentVariable("tenantID");
            var certThumbPrint = Environment.GetEnvironmentVariable("CertThumbPrint");
            strSysLogTracker = Environment.GetEnvironmentVariable("sysLogTracker");
            IsSandBoxTest = Convert.ToBoolean(Environment.GetEnvironmentVariable("IsSandBoxTest"));
            objAzFncPL.clientID = clientId;
            objAzFncPL.tenantID = tenantId;
            objAzFncPL.CertThumbPrint = certThumbPrint;
            string token = await getAuthendicatedToken(objAzFncPL);
            var context = new ClientContext(ecmURL);
            context.ExecutingWebRequest += (sender, e) =>
            {
                e.WebRequestExecutor.RequestHeaders["Authorization"] = "Bearer " + token;
            };

            //log.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");
           // LogTracker(context, "Testing from RCTimmer", "Test");
            ExecutePromoteToRecordRequests(context, _context);
        }
        private static void InitVariables()
        {
            ecmURL = Environment.GetEnvironmentVariable("EcmURL");
            configListName = Environment.GetEnvironmentVariable("configListName");
            requestListName = Environment.GetEnvironmentVariable("RequestListName");
        }
        public static async Task<string> getAuthendicatedToken(AzFncPL objAzFncPL)
        {

            var scopes = new string[] { "https://petronas.sharepoint.com/.default" };
            var accessToken = await GetAppAuthedicatedClient(objAzFncPL.clientID, objAzFncPL.CertThumbPrint, scopes, objAzFncPL.tenantID);

            // var accessToken = await GetAppAuthedicatedClient("56755962-d144-4273-81e9-193599ca1aa3", "2E9454F4668A3D17A121583BD6566EC5FFC0EE5A", scopes, "1f4fcefa-f4c6-435d-8dbc-41b312d74871");
            //
            return accessToken;
        }
        internal static async Task<string> GetAppAuthedicatedClient(string clientID, string thumbPrint, string[] scopes, string tenantID)
        {
            X509Certificate2 cert = getAppOnlyCert(thumbPrint);
            IConfidentialClientApplication clientApp = ConfidentialClientApplicationBuilder
                .Create(clientID)
                .WithCertificate(cert)
                .WithTenantId(tenantID)
                .Build();
            AuthenticationResult authResult = await clientApp.AcquireTokenForClient(scopes).ExecuteAsync();
            string strAccessToken = authResult.AccessToken;
            return strAccessToken;
        }
        private static X509Certificate2 getAppOnlyCert(string strThumbPrint)
        {
           /* var certName = "protected.pfx";
            var certPassword = "pass@word1";
            var certPath = @"D:\Britto\ECMS\Upstream\Scripts\" + certName;
            X509Certificate2 appOnlyCert = new X509Certificate2(
                System.IO.File.ReadAllBytes(certPath),
                certPassword,
                X509KeyStorageFlags.Exportable |
                X509KeyStorageFlags.MachineKeySet |
                X509KeyStorageFlags.PersistKeySet);
            return appOnlyCert;
           */
            X509Certificate2 appOnlyCert = null;
            
            using (X509Store certStore = new X509Store(StoreName.My, StoreLocation.CurrentUser))
            {
                certStore.Open(OpenFlags.ReadOnly);
                X509Certificate2Collection certCollection = certStore.Certificates.Find(X509FindType.FindByThumbprint, strThumbPrint, false);
                if (certCollection.Count > 0)
                {
                    appOnlyCert = certCollection[0];
                }
                certStore.Close();
                return appOnlyCert;
            }
           
        }
        private static void ExecutePromoteToRecordRequests(ClientContext clientContext, ExecutionContext _context)
        {
            try
            {
                var newconfiguration = new ConfigurationBuilder()
               .SetBasePath(_context.FunctionAppDirectory)
               .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
               .AddEnvironmentVariables()
               .Build();

                //  ClientContext rcDocContext = null;
                Web oWebsite = clientContext.Web;
                clientContext.Load(oWebsite);
                clientContext.ExecuteQuery();
                Console.WriteLine("rc source url: " + oWebsite.Url);
                var sysRCSitesList = clientContext.Web.Lists.GetByTitle(configListName);

                clientContext.Load(sysRCSitesList);
                clientContext.ExecuteQuery();

                var rcItems = sysRCSitesList.GetItems(CamlQuery.CreateAllItemsQuery());
                clientContext.Load(rcItems);
                clientContext.ExecuteQuery();

                if (rcItems.Count > 0)
                {
                    foreach (var rcItem in rcItems)
                    {
                        recordCenterURL = Convert.ToString(rcItem["Title"]);
                        Console.WriteLine("");
                        Console.WriteLine("RecordCenterURL: " + recordCenterURL);


                        if (!string.IsNullOrWhiteSpace(recordCenterURL))
                        {
                            if (IsSandBoxTest)
                            {
                                if (recordCenterURL.Contains("recordcenter-test"))
                                {
                                    using (var rcContext = clientContext.Clone(recordCenterURL))
                                    {

                                        GetRecordCenterRequestList(rcContext, _context);

                                    }
                                }
                            }
                            else
                            {
                                using (var rcContext = clientContext.Clone(recordCenterURL))
                                {

                                    GetRecordCenterRequestList(rcContext, _context);

                                }
                            }
                    }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                LogTracker(clientContext, "ExecutePromoteToRecordRequests", ex.Message.ToString());
            }

        }
        private static void GetRecordCenterRequestList(ClientContext clientContext, ExecutionContext _context)
        {
            var newconfiguration = new ConfigurationBuilder()
              .SetBasePath(_context.FunctionAppDirectory)
              .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
              .AddEnvironmentVariables()
              .Build();
            Web oWebsite = clientContext.Web;
            clientContext.Load(oWebsite);
            clientContext.ExecuteQuery();

            List targetList = oWebsite.Lists.GetByTitle(requestListName);
            clientContext.Load(targetList);
            clientContext.ExecuteQuery();
            Console.WriteLine("targetList: " + targetList.Title);
            CamlQuery oQuery = new CamlQuery()
            {
                ViewXml = camlquery_str
            };

            //ListItemCollection oCollection = targetList.GetItems(oQuery);

            ListItemCollection oCollection = targetList.GetItems(CamlQuery.CreateAllItemsQuery()); ;
            clientContext.Load(oCollection);
            clientContext.ExecuteQuery();
            var list = new List<QueueMessagePL>();
            foreach (ListItem oItem in oCollection)
            {
                if (Convert.ToString(oItem["RecordStatus"]) == "Approved")
                {
                    try
                    {

                        list.Add(new QueueMessagePL()
                        {
                            SiteURL = oWebsite.Url.Trim(),
                            ItemID = Convert.ToString(oItem.Id),
                            ListName = requestListName,
                            DocumentSourceURLs = Convert.ToString(oItem["DocumentSourceURLs"])
                        });

                       // string strQueValue = $"{oWebsite.Url}|{targetList.Title}|{oItem.Id}";
                        Console.WriteLine($"Details: {oWebsite.Url} ,{targetList.Title},{oItem.Id}");
                        //  log.LogInformation($"Details: {oWebsite.Url} , {targetList.DefaultViewUrl},{targetList.Title},{oItem.Id}");

                        // Parse the connection string   
                        // Return a reference to the storage account.  
                        CloudStorageAccount storageAccount = CloudStorageAccount.Parse(newconfiguration["AzureWebJobsStorage"]);
                        //StorageConnectionString

                        // Create the queue client.  
                        CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();

                        // Retrieve queue reference from the container  
                        CloudQueue queue = queueClient.GetQueueReference("rc-request-item-queue");

                        // Create queue if it does not exist  
                        queue.CreateIfNotExistsAsync();

                        //Create message   
                        // CloudQueueMessage message = new CloudQueueMessage(strQueValue.ToString().Trim());
                        CloudQueueMessage message = new CloudQueueMessage(JsonConvert.SerializeObject(list));

                        //Add message to queue  
                        queue.AddMessageAsync(message);

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        LogTracker(clientContext, "GetRecordCenterRequestList", ex.Message.ToString());
                    }
                }
            }
        }

        private static void LogTracker(ClientContext clientContext, string strMethodName, string strErrorMsg)
        {
            using (ClientContext srcContext = clientContext.Clone(ecmURL))
            {
                Web oWebsite = srcContext.Web;
                srcContext.Load(oWebsite);
                srcContext.ExecuteQuery();

                List targetList = oWebsite.Lists.GetByTitle(strSysLogTracker);
                srcContext.Load(targetList);
               
                ListItemCreationInformation oListItemCreationInformation = new ListItemCreationInformation();
                ListItem oItem = targetList.AddItem(oListItemCreationInformation);
                oItem["SchedulerName"] = "AzFnDeclareRecord";
                oItem["MethodName"] = strMethodName;
                oItem["ErrorMessage"] = strErrorMsg;
                oItem["Title"] = "Error Log";

                oItem.Update();
                srcContext.ExecuteQuery();

            }
        }

    }
}
