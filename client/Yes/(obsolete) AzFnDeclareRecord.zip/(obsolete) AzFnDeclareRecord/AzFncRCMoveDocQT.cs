using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Client;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.Taxonomy;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using ST = System.Threading;

namespace ECM_AzFnDeclareRecord
{
    public static class AzFncRCMoveDocQT
    {
        public static string ecmURL = "";
        public static string configListName = "";
        public static string requestCenterURL = "";
        public static string sysRCListName = "";
        public static string requestListName = "";
        public static string itemNumber = "";
        public static string strRecordCenter = "";
        public static string strSiteCollName = "";
        public static string strLibName = "";
        public static string strRCDocURL = "";
        public static string baseUrl = "";
        public static bool useMoveFile = false;
        public static string strSourceLibName = "";
        public static string strSysLogTracker = "";

        [FunctionName("AzFncRCMoveDocQT")]
        public static async Task Run([QueueTrigger("rc-request-item-queue", Connection = "AzureWebJobsStorage")]string myQueueItem, ILogger log, ExecutionContext _context)
        {
            InitVariables();
            var newconfiguration = new ConfigurationBuilder()
               .SetBasePath(_context.FunctionAppDirectory)
               .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
               .AddEnvironmentVariables()
               .Build();
            // var token = await TokenProvider.GetAccessTokenAsync(new Uri(ecmURL).GetLeftPart(UriPartial.Authority));
            var objAzFncPL = new AzFncPL();
            var clientId = Environment.GetEnvironmentVariable("clientID");
            var tenantId = Environment.GetEnvironmentVariable("tenantID");
            var certThumbPrint = Environment.GetEnvironmentVariable("CertThumbPrint");
            strSysLogTracker = Environment.GetEnvironmentVariable("sysLogTracker");
            objAzFncPL.clientID = clientId;
            objAzFncPL.tenantID = tenantId;
            objAzFncPL.CertThumbPrint = certThumbPrint;

            List<QueueMessagePL> items = JsonConvert.DeserializeObject<List<QueueMessagePL>>(myQueueItem);


            string token = await getAuthendicatedToken(objAzFncPL);
            foreach (var item in items)
            {

                requestCenterURL = item.SiteURL;
                requestListName =item.ListName;
                itemNumber = item.ItemID;
                strRCDocURL = item.DocumentSourceURLs;
            }
          

            var context = new ClientContext(requestCenterURL);
            context.ExecutingWebRequest += (sender, e) =>
            {
                e.WebRequestExecutor.RequestHeaders["Authorization"] = "Bearer " + token;
            };

            //log.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");

            //  ExecutePromoteToRecordRequests(context, _context);
         //   LogTracker(context, "Testing from RCMoveDocQT", "Test");
            MoveDocumentToRecordCenter(context, strRCDocURL, _context);
            log.LogInformation($"C# Queue trigger function processed: {myQueueItem}");
        }

        private static void InitVariables()
        {
            ecmURL = Environment.GetEnvironmentVariable("EcmURL");
            configListName = Environment.GetEnvironmentVariable("configListName");
            strRecordCenter = Environment.GetEnvironmentVariable("RecordCenter");
        }
        public static async Task<string> getAuthendicatedToken(AzFncPL objAzFncPL)
        {

            var scopes = new string[] { "https://petronas.sharepoint.com/.default" };
            var accessToken = await GetAppAuthedicatedClient(objAzFncPL.clientID, objAzFncPL.CertThumbPrint, scopes, objAzFncPL.tenantID);

            // var accessToken = await GetAppAuthedicatedClient("56755962-d144-4273-81e9-193599ca1aa3", "2E9454F4668A3D17A121583BD6566EC5FFC0EE5A", scopes, "1f4fcefa-f4c6-435d-8dbc-41b312d74871");
            //
            return accessToken;
        }
        internal static async Task<string> GetAppAuthedicatedClient(string clientID, string thumbPrint, string[] scopes, string tenantID)
        {
            X509Certificate2 cert = getAppOnlyCert(thumbPrint);
            IConfidentialClientApplication clientApp = ConfidentialClientApplicationBuilder
                .Create(clientID)
                .WithCertificate(cert)
                .WithTenantId(tenantID)
                .Build();
            AuthenticationResult authResult = await clientApp.AcquireTokenForClient(scopes).ExecuteAsync();
            string strAccessToken = authResult.AccessToken;
            return strAccessToken;
        }
        private static X509Certificate2 getAppOnlyCert(string strThumbPrint)
        {
            /* var certName = "protected.pfx";
             var certPassword = "pass@word1";
             var certPath = @"D:\Britto\ECMS\Upstream\Scripts\" + certName;
             X509Certificate2 appOnlyCert = new X509Certificate2(
                 System.IO.File.ReadAllBytes(certPath),
                 certPassword,
                 X509KeyStorageFlags.Exportable |
                 X509KeyStorageFlags.MachineKeySet |
                 X509KeyStorageFlags.PersistKeySet);
             return appOnlyCert;
            */
            X509Certificate2 appOnlyCert = null;

            using (X509Store certStore = new X509Store(StoreName.My, StoreLocation.CurrentUser))
            {
                certStore.Open(OpenFlags.ReadOnly);
                X509Certificate2Collection certCollection = certStore.Certificates.Find(X509FindType.FindByThumbprint, strThumbPrint, false);
                if (certCollection.Count > 0)
                {
                    appOnlyCert = certCollection[0];
                }
                certStore.Close();
                return appOnlyCert;
            }

        }


        private static void MoveDocumentToRecordCenter(ClientContext clientContext, string documentsPromoted, ExecutionContext _context)
        {
           
            Web oWebsite = clientContext.Web;
            clientContext.Load(oWebsite);
            clientContext.ExecuteQuery();
            List targetList = oWebsite.Lists.GetByTitle(requestListName);
            clientContext.Load(targetList);
            clientContext.ExecuteQuery();

            var oItem = targetList.GetItemById(Convert.ToInt32(itemNumber));

            clientContext.Load(oItem);
            clientContext.ExecuteQuery();


            StringBuilder errorSb = new StringBuilder();

            baseUrl = (new Uri(oWebsite.Url)).GetLeftPart(UriPartial.Authority);


            var rcWebURL = GetWebUrl(clientContext, $"{baseUrl}{documentsPromoted}");
            strSiteCollName = GetRecordCenterSiteCollName($"{baseUrl}/sites/", rcWebURL);
            var subSiteName = GetRecordCenterSubSiteName($"{baseUrl}/sites/", rcWebURL);
            if (strSiteCollName.Equals(subSiteName))
            {
                strLibName = "Default";
            }
            else
            {
                strLibName = subSiteName;// GetRecordCenterLibName($"{baseUrl}{documentsPromoted}", rcWebURL);
            }
            strSourceLibName = GetRecordCenterLibName($"{baseUrl}{documentsPromoted}", rcWebURL);
            string strRcDestSiteURL = string.Format("{0}/sites/{1}", baseUrl, strSiteCollName);
            string destRecordCenterURL = strRcDestSiteURL + "/" + strRecordCenter;



            // Create folder
            List<KeyValuePair<string, string>> oItemParams = null;
            try
            {


                var fullFilePath = $"{baseUrl}{documentsPromoted}";

                Uri uri = new Uri(fullFilePath);
                string filename = System.IO.Path.GetFileName(uri.LocalPath);

                oItemParams = new List<KeyValuePair<string, string>>();

                var (movedItem, iWebURL) = GetOldItemProperties(clientContext, documentsPromoted);

                if (movedItem == null)
                {
                    errorSb.AppendLine($"{documentsPromoted} does not exists.");
                    // continue;
                }

                var destFolder = "";
                //string sourceFolder = tenantURL + documentPromoted;


                Console.WriteLine("Moved file1");

                using (ClientContext srcContext = clientContext.Clone(destRecordCenterURL))
            {
                var sFolderPath = fullFilePath.Replace(iWebURL, "/").Replace(filename, "");

                var folderUrl = TryCreateDestFolderPath(srcContext, strLibName, sFolderPath);

                if (string.IsNullOrWhiteSpace(folderUrl))
                {
                    errorSb.AppendLine($"Cannot create {sFolderPath} at {srcContext.Url}.");
                    //continue;
                }

                destFolder = $"{baseUrl}{folderUrl}/{filename}";

                Console.WriteLine("destFolder: " + destFolder);

                MoveCopyOptions option = new MoveCopyOptions();
                option.KeepBoth = false;

                option.RetainEditorAndModifiedOnMove = true;
                option.ShouldBypassSharedLocks = true;

                MoveCopyUtil.MoveFile(srcContext, fullFilePath, destFolder, false, option);

                srcContext.ExecuteQuery();

                Console.WriteLine(filename + " - Moved");

                File fileDoc = TryGetFile(srcContext, destFolder.Replace(baseUrl, ""));

                // Update file properties
                ListItem item = TryGetListItemByFile(srcContext, destFolder.Replace(baseUrl, ""));

                if (item == null) { }
                //  continue;

                List spLst = item.ParentList;
                srcContext.Load(spLst);
                srcContext.ExecuteQuery();
                var fields = spLst.Fields;
                srcContext.Load(fields);
                srcContext.ExecuteQuery();

                User approverName = EnsuerUsers(srcContext, ((Microsoft.SharePoint.Client.FieldUserValue)oItem["Approver"]).Email);

                TrySetTaxonomyValue(srcContext, oItem, item, "Business_x0020_Metadata", fields);
                TrySetTaxonomyValue(srcContext, oItem, item, "Discipline_x0020_Metadata", fields);
                TrySetTaxonomyValue(srcContext, oItem, item, "ECMS_x0020_Record_x0020_Type", fields);

                item["Document_x0020_Structure"] = oItem["DocumentStructure"];
                item["Expiry_x0020_Date"] = oItem["ExpiryDate"];
                item["Security_x0020_Classification"] = oItem["Security_x0020_Classification"];
                item["Vital_x0020_Classification"] = oItem["VitalClassification"];
                item["Revision_x0020_No"] = oItem["RevisionNo"];
                item["DocumentSourceURLs"] = oItem["DocumentSourceURLs"];
                item["Record_x0020_Status"] = oItem["RecordStatus"];

                item["Approval_x0020_Date"] = oItem["ApprovalDate"];
                    item["Approver"] = approverName;// oItem["Approver"];

                item.Update();
                srcContext.Load(item);
                srcContext.ExecuteQuery();

                // Check in the file
                srcContext.Load(fileDoc);
                srcContext.ExecuteQuery();
                fileDoc.CheckIn("", CheckinType.MajorCheckIn);
                srcContext.ExecuteQuery();


                //Records.DeclareItemAsRecord(srcContext, item);
                //srcContext.Load(item);
                //srcContext.ExecuteQuery();

                    Console.WriteLine(filename + " - Checked in");

            }
                var mStatus = UpdateSourceFile(clientContext, documentsPromoted, destFolder, movedItem);

                if (!string.IsNullOrWhiteSpace(mStatus))
                    errorSb.AppendLine(mStatus);

            }
            catch (Exception ex)
                {
                    errorSb.AppendLine($"{documentsPromoted} :: {ex.Message}");
                LogTracker(clientContext, "MoveDocumentToRecordCenter", ex.Message.ToString());
            }

          

            if (oItem != null)
            {
                UpdateRecordStatus(clientContext, oItem.Id, errorSb);
            }
        }

        private static User EnsuerUsers(ClientContext clientContext, string emailAddress)
        {
            Web web = clientContext.Web;
            var _User = web.EnsureUser(emailAddress);
            clientContext.Load(_User);
            clientContext.ExecuteQuery();
            return _User;
            /*
            var result = Microsoft.SharePoint.Client.Utilities.Utility.ResolvePrincipal(clientContext, clientContext.Web, emailAddress, Microsoft.SharePoint.Client.Utilities.PrincipalType.User, Microsoft.SharePoint.Client.Utilities.PrincipalSource.All, null, true);
            clientContext.ExecuteQuery();
            if (result != null)
            {
              var   user = clientContext.Web.EnsureUser(result.Value.LoginName);
                clientContext.Load(user);
                clientContext.ExecuteQuery();
                return user;
            }
           */


        }
        private static string GetWebUrl(ClientContext clientContext,string strfileFullPath)
        {
            string fileUrl = strfileFullPath;
            Uri fileUri = new Uri(fileUrl);
            Uri webUrl;
            string strWebURL = "";
            try
            {
                string strBaseURL = fileUri.Scheme + Uri.SchemeDelimiter + fileUri.Host;
                ClientContext rootContext = clientContext.Clone(strBaseURL);
                webUrl = Web.WebUrlFromPageUrlDirect(rootContext, fileUri);

                strWebURL = webUrl.ToString();
            }
            catch (Exception ex)
            {

                LogTracker(clientContext, "GetWebUrl", ex.Message.ToString());
            }


            return strWebURL;


        }
        private static string GetRecordCenterSiteCollName(string strBaseURL, string documentsPromoted)
        {
            string[] siteCollName = documentsPromoted.Replace(strBaseURL, "").Split('/');
            return Convert.ToString(siteCollName[0]);
        }
        private static string GetRecordCenterSubSiteName( string strBaseURL, string documentsPromoted)
        {
            string[] siteCollName = documentsPromoted.Replace(strBaseURL, "").Split('/');
            if (siteCollName.Count() > 1)
            {
                return Convert.ToString(siteCollName[1]);
            }
            else
            {
                return Convert.ToString(siteCollName[0]);
            }
           
        }

        private static string GetRecordCenterLibName( string documentsPromoted, string strRCWebURL)
        {
            string[] siteCollName = documentsPromoted.Replace($"{strRCWebURL}/", "").Split('/');
            return Convert.ToString(siteCollName[0]);
        }
        private static List<string> GetItemtoMove(string documentURL, string tenantURL)
        {
            List<string> items = new List<string>();

            if (string.IsNullOrWhiteSpace(documentURL))
                return items;

            if (documentURL.IndexOf($";/sites/") > 0)
            {
                // we have more than 1 item to move
                var temps = documentURL.Split(new[] { $";/sites/" }, StringSplitOptions.RemoveEmptyEntries).ToList();

                foreach (var temp in temps)
                {
                    var item = temp;
                    if (temp.EndsWith(".url"))
                        continue;

                    if (!temp.StartsWith("/sites/"))
                        item = $"/sites/{temp}";

                    items.Add(item);
                }
                // items.AddRange(temps.Where(x => !x.EndsWith(".url")).ToList());
            }
            else
            {
                items.Add(documentURL);
            }

            return items;
        }

        private static TaxonomyFieldValue tryParseTaxonomyFieldValue(ListItem item, string fieldName)
        {
            if (item == null)
                throw new ArgumentNullException("item");

            TaxonomyFieldValue t1 = item[fieldName] as TaxonomyFieldValue;

            if (t1 != null)
            {
                return t1;
            }

            Dictionary<string, object> t2 = item[fieldName] as Dictionary<string, object>;
            if (t2 != null)
            {
                return ConvertDictionaryToTaxonomyFieldValue(t2);
            }

            return null;
        }

        private static TaxonomyFieldValue ConvertDictionaryToTaxonomyFieldValue(Dictionary<string, object> dictionary)
        {
            try
            {
                string ObjectType = "_ObjectType_";
                if (!dictionary.ContainsKey(ObjectType) || !dictionary[ObjectType].Equals("SP.Taxonomy.TaxonomyFieldValue"))
                {
                    throw new InvalidOperationException("Dictionary value represents no TaxonomyFieldValue.");
                }

                return new TaxonomyFieldValue
                {
                    Label = dictionary["Label"].ToString(),
                    TermGuid = dictionary["TermGuid"].ToString(),
                    WssId = int.Parse(dictionary["WssId"].ToString(), CultureInfo.InvariantCulture)
                };
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        private static (ListItem, string) GetOldItemProperties(ClientContext clientContext, string srcFile)
        {
            //  var subSiteUrl = GetSourceSiteURL(srcFile);
            var data = new List<KeyValuePair<string, string>>(); ;

            try
            {
                ClientContext srcContext;
                var url = $"{baseUrl}{srcFile}";
                if (srcFile.IndexOf(baseUrl) >= 0)
                    url = srcFile;

                if (!TryResolveClientContext(new Uri(url), out srcContext, clientContext))
                {
                    return (null, null);
                }

                using (srcContext)
                {
                    return (TryGetListItemByFile(srcContext, srcFile), srcContext.Url);
                }
            }
            catch (Exception ex)
            {
                LogTracker(clientContext, "GetOldItemProperties", ex.Message.ToString());
                return (null, null);
            }
        }

        public static bool TryResolveClientContext(Uri requestUri, out ClientContext context, ClientContext fContext)
        {
            context = null;
            var baseUrl = requestUri.GetLeftPart(UriPartial.Authority);
            for (int i = requestUri.Segments.Length; i >= 0; i--)
            {
                var path = string.Join(string.Empty, requestUri.Segments.Take(i));
                string url = string.Format("{0}{1}", baseUrl, path);
                try
                {
                    context = fContext.Clone(url);
                    context.ExecuteQuery();
                    return true;
                }
                catch (Exception ex) {
                
                }
            }
            return false;
        }

        private static ListItem TryGetListItemByFile(ClientContext ctx, string filePath)
        {

            try
            {
                File fileDoc = ctx.Web.GetFileByServerRelativeUrl(filePath.Replace(baseUrl, ""));
                ListItem item = fileDoc.ListItemAllFields;
                ctx.Load(item);
                ctx.Load(item.ParentList);
                ctx.Load(item.File);
                ctx.ExecuteQuery();
                return item;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"TryGetListItemByFile Error:: {ex.Message}");
                LogTracker(ctx, "TryGetListItemByFile", ex.Message.ToString());

            }
            return null;
        }
        public static string TryCreateDestFolderPath(ClientContext distContext, string listName, string tempPath)
        {
            try
            {
                Console.WriteLine("running TryCreateDestFolderPath");
                

                var folders = tempPath.Split('/');


                var folder = distContext.Web.EnsureFolderPath($"/{listName}{tempPath}");

                distContext.Load(folder);
                distContext.ExecuteQuery();
                ST.Thread.Sleep(1000);


                var isExists = distContext.Web.DoesFolderExists(folder.ServerRelativeUrl);

 

                if (!isExists)
                {
                    Console.WriteLine($"TryCreateDestFolderPath::{folder.ServerRelativeUrl} fail.Retry");

                    var folderR1 = distContext.Web.EnsureFolderPath($"/{listName}{tempPath}");
                    distContext.Load(folderR1);
                    distContext.ExecuteQuery();
                }

                var folder1 = distContext.Web.GetFolderByServerRelativePath(ResourcePath.FromDecodedUrl(folder.ServerRelativeUrl));

                distContext.Load(folder1);
                distContext.ExecuteQuery();

                return folder1.ServerRelativeUrl;
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
                LogTracker(distContext, "TryCreateDestFolderPath", ex.Message.ToString());
            }
            return string.Empty;
        }

        private static File TryGetFile(ClientContext ctx, string filePath)
        {

            try
            {
                File fileDoc = ctx.Web.GetFileByServerRelativeUrl(filePath.Replace(baseUrl, ""));
                ctx.Load(fileDoc, f => f.Exists, f => f.CheckOutType);
                ctx.ExecuteQuery();
                return fileDoc;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"TryGetFile Error:: {ex.Message}");
                LogTracker(ctx, "TryGetFile", ex.Message.ToString());
            }
            return null;
        }
        private static void TrySetTaxonomyValue(ClientContext ctx, ListItem oItem, ListItem nItem, string fieldName, FieldCollection fields)
        {
            var g1 = fields.Where(x => x.InternalName == fieldName).FirstOrDefault();

            if (g1 == null)
                return;

            var t1 = tryParseTaxonomyFieldValue(oItem, fieldName);

            if (t1 != null)
            {
                nItem.SetTaxonomyFieldValue(g1.Id, t1.Label, Guid.Parse(t1.TermGuid));
            }
            else
            {
                throw new ArgumentNullException("TaxonomyFieldValue null");
            }
        }
        private static string UpdateSourceFile(ClientContext clientContext, string documentsPromoted, string destFile, ListItem oItem)
        {
            

            string sourceFile = baseUrl + documentsPromoted;

            string[] temp = documentsPromoted.Trim().Split('/');

             
            string fileName = temp[temp.Length - 1]; // last row

        


            ClientContext srcContext;

            if (!TryResolveClientContext(new Uri(sourceFile), out srcContext, clientContext))
            {
                return $"UpdateSourceFile::Cannot find ClientContext for {sourceFile}";
            }

            // Create link in source folder to dest file
            using (srcContext)
            {
                var lib = srcContext.Web.GetListById(oItem.ParentList.Id);
                srcContext.Load(lib);
                srcContext.ExecuteQuery();

                FileCreationInformation itemCreateInfo = new FileCreationInformation();
                itemCreateInfo.Overwrite = true;
                itemCreateInfo.Url = fileName + ".url";
                itemCreateInfo.Content = Encoding.ASCII.GetBytes("[InternetShortcut]URL = " + destFile);

                // Folder newFolder = lib.RootFolder;
                var tempPath = documentsPromoted.Replace(fileName, "");
                Folder newFolder = srcContext.Web.GetFolderByServerRelativeUrl(tempPath);
                

                var newItem = newFolder.Files.Add(itemCreateInfo);
                srcContext.Load(newItem);
                srcContext.ExecuteQuery();

                // todo: set item properties to original

                var _FileItem = newItem.ListItemAllFields;
                _FileItem["Title"] = oItem["Title"];
                if (_FileItem.FieldValues.Any(x => x.Key == "Security Classification"))
                {
                    _FileItem["Security Classification"] = oItem["Security Classification"];
                }

                if (_FileItem.FieldValues.Any(x => x.Key == "Vital Classification"))
                {
                    _FileItem["Vital Classification"] = oItem["Vital Classification"];
                }

                if (_FileItem.FieldValues.Any(x => x.Key == "Business GTS"))
                {
                    _FileItem["Business GTS"] = oItem["Business GTS"];
                }

                if (_FileItem.FieldValues.Any(x => x.Key == "Domain GTS"))
                {
                    _FileItem["Domain GTS"] = oItem["Domain GTS"];
                }

                _FileItem["Created"] = oItem["Created"];
                _FileItem["Modified"] = oItem["Modified"];
                _FileItem["Author"] = oItem["Author"];
                _FileItem["Editor"] = oItem["Editor"];

                FieldUrlValue u = new FieldUrlValue();
                u.Url = destFile;
                u.Description = "Moved to record center";
                _FileItem["_ShortcutUrl"] = u;
                _FileItem.Update();

                srcContext.ExecuteQuery();
                Console.WriteLine("Source linked");

                if (!useMoveFile)
                {
                    // clean up file
                    try
                    {
                        File f1 = srcContext.Web.GetFileByServerRelativeUrl(oItem.File.ServerRelativeUrl);
                        if (f1 != null)
                        {
                            f1.DeleteObject();
                            srcContext.ExecuteQuery();
                        }
                    }
                    catch (Exception ex)
                    {
                        LogTracker(clientContext, "UpdateSourceFile", ex.Message.ToString());
                        return ex.Message;
                    }
                }

                return string.Empty;
            }
        }

        private static void UpdateRecordStatus(ClientContext clientContext, int ID, StringBuilder sb)
        {
            using (clientContext)
            {
                // This value is NOT List internal name
                List targetList = clientContext.Web.Lists.GetByTitle(requestListName);

                // Get Item by ID
                ListItem oItem = targetList.GetItemById(ID);

                // Update status


                if (sb.Length > 0)
                {
                    oItem["RecordStatus"] = "Error";
                }
                else
                {
                    oItem["RecordStatus"] = "Completed";
                }

                oItem["Remarks"] = sb.ToString();

                

                oItem.Update();
                clientContext.ExecuteQuery();

                Console.WriteLine("Record updated to Promoted");
            }
        }

        private static void LogTracker(ClientContext clientContext, string strMethodName, string strErrorMsg)
        {
            using (ClientContext srcContext = clientContext.Clone(ecmURL))
            {
                Web oWebsite = srcContext.Web;
                srcContext.Load(oWebsite);
                srcContext.ExecuteQuery();

                List targetList = oWebsite.Lists.GetByTitle(strSysLogTracker);
                srcContext.Load(targetList);

                ListItemCreationInformation oListItemCreationInformation = new ListItemCreationInformation();
                ListItem oItem = targetList.AddItem(oListItemCreationInformation);
                oItem["SchedulerName"] = "AzFnDeclareRecord";
                oItem["MethodName"] = strMethodName;
                oItem["ErrorMessage"] = strErrorMsg;
                oItem["Title"] = "Error Log";

                oItem.Update();
                srcContext.ExecuteQuery();

            }
        }


    }
}
