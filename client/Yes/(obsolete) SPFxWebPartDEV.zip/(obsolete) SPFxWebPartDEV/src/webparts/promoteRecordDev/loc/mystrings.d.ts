declare interface IPromoteRecordDevWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'PromoteRecordDevWebPartStrings' {
  const strings: IPromoteRecordDevWebPartStrings;
  export = strings;
}
