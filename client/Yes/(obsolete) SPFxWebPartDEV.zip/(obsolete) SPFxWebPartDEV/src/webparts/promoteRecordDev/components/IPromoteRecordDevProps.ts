import { WebPartContext } from "@microsoft/sp-webpart-base";  

export interface IPromoteRecordProps {
  description: string;
  context: WebPartContext;
  SysRecordListPath: string;
  ApproversGroupName: string;
  SysRecordListName : string;
  disciplineMetadataTermsetSource:string[];
  businessMetadataTermSetSource:string[];
}
