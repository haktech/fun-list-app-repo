import * as React from 'react';
import styles from './PromoteRecordDev.module.scss';
import { IPromoteRecordProps } from './IPromoteRecordDevProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { DateTimePicker, DateConvention, TimeConvention } from '@pnp/spfx-controls-react/lib/DateTimePicker';
// import { TaxonomyPicker, IPickerTerms, TermActionsDisplayMode } from "@pnp/spfx-controls-react/lib/TaxonomyPicker";
import { TaxonomyPicker, IPickerTerms, TermActionsDisplayMode } from "../../../controls/taxonomyPicker";
import { IItemAddResult } from "@pnp/sp/items";
import { containsInvalidFileFolderChars, sp } from "@pnp/sp";
import { Web } from "@pnp/sp/presets/core";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/fields";
import "@pnp/sp/column-defaults";
import "@pnp/sp/site-users/web";
import { Dropdown, DropdownMenuItemType, IDropdownOption, IDropdownProps } from 'office-ui-fabric-react/lib/Dropdown';
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import { DefaultButton, PrimaryButton } from 'office-ui-fabric-react/lib/Button';
import { Stack, IStackProps, IStackStyles } from 'office-ui-fabric-react/lib/Stack';
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import "@pnp/sp/files";

export interface IPromoteRecordsWebPartState {
  fromUrl;
  documentIds;

  sClassificationValue;
  sClassificationTitle;
  sClassificationChoices: IDropdownOption[];
  VitalClassificationValue;
  VitalClassificationTitle;
  VitalClassificationChoices: IDropdownOption[];
  DocumentStructureValue;
  DocumentStructureTitle;
  DocumentStructureChoices: IDropdownOption[];

  businessMetadataValue;
  businessMetadataAllowMulti;
  businessMetadataTermset;
  businessMetadataTitle;
  businessMetadataShowTerms: string[];

  recordTypeMetadataValue;
  recordTypeMetadataAllowMulti;
  recordTypeMetadataTermset;
  recordTypeMetadataTitle;

  disciplineMetadataValue;
  disciplineMetadataAllowMulti;
  disciplineMetadataTermset;
  disciplineMetadataTitle;
  //discipline

  RevisionNoValue;
  ExpiryDateValue;
  RevisionNoTitle;
  ExpiryDateTitle;
  businessMetadataValid;
  approver;
  approversGroupName;
  onSubmission;
  isSubmited;
  IsCancelled;
  requireMsg;
  IsMisconfiguration;
}

const stackStyles: Partial<IStackStyles> = { root: { width: 650 } };
const stackTokens = { childrenGap: 20 };

export default class PromoteRecord extends React.Component<IPromoteRecordProps, IPromoteRecordsWebPartState> {

  private cfields: any = [
    {
      name: "ECMS_x0020_Record_x0020_Type",
      type: "taxonomy",
      title: "recordTypeMetadataTitle",
      select: "TermSetId",
      state: "recordTypeMetadataTermset"
    }, {
      name: "Discipline_x0020_Metadata",
      type: "taxonomy",
      title: "disciplineMetadataTitle",
      select: "TermSetId",
      state: "disciplineMetadataTermset"
    }, {
      name: "Business_x0020_Metadata",
      type: "taxonomy",
      title: "businessMetadataTitle",
      select: "TermSetId",
      state: "businessMetadataTermset"
    },
    {
      name: "Security_x0020_Classification",
      type: "choice",
      select: "Choices",
      title: "sClassificationTitle",
      state: "sClassificationChoices"
    },
    {
      name: "VitalClassification",
      type: "choice",
      title: "VitalClassificationTitle",
      select: "Choices",
      state: "VitalClassificationChoices"
    },
    {
      name: "DocumentStructure",
      type: "choice",
      select: "Choices",
      title: "DocumentStructureTitle",
      state: "DocumentStructureChoices"
    },
    {
      name: "RevisionNo",
      type: "text",
      select: null,
      title: "RevisionNoTitle",
      state: null
    },
    {
      name: "ExpiryDate",
      type: "date",
      select: null,
      title: "ExpiryDateTitle",
      state: null
    }
  ];

  //DocumentStructure

  constructor(props: IPromoteRecordProps) {
    super(props);
    sp.setup({ spfxContext: this.props.context });

    this.state = {
      sClassificationValue: undefined,
      sClassificationTitle: undefined,
      sClassificationChoices: [],
      VitalClassificationValue: undefined,
      VitalClassificationTitle: undefined,
      VitalClassificationChoices: [],
      DocumentStructureValue: undefined,
      DocumentStructureTitle: undefined,
      DocumentStructureChoices: [],

      businessMetadataValue: undefined,
      businessMetadataTermset: undefined,
      businessMetadataTitle: undefined,
      businessMetadataShowTerms: [],
      businessMetadataValid: true,
      recordTypeMetadataValue: undefined,
      recordTypeMetadataTermset: undefined,
      recordTypeMetadataTitle: undefined,
      disciplineMetadataValue: undefined,
      disciplineMetadataTermset: undefined,
      disciplineMetadataTitle: undefined,

      businessMetadataAllowMulti: false,
      disciplineMetadataAllowMulti: false,
      recordTypeMetadataAllowMulti: false,

      ExpiryDateValue: new Date(),
      RevisionNoValue: "",
      RevisionNoTitle: undefined,
      ExpiryDateTitle: undefined,
      approver: undefined,
      approversGroupName: undefined,
      documentIds: [],
      fromUrl: "",
      onSubmission: false,
      isSubmited: false,
      IsCancelled: false,
      requireMsg: "You can't leave this blank.",
      IsMisconfiguration: false
    };

    // this._handleChoices = this._handleChoices.bind(this);
    // this.onSingleSelectTaxPickerChange = this.onSingleSelectTaxPickerChange.bind(this);
    this._getPeoplePickerItems = this._getPeoplePickerItems.bind(this);

    this.onRecordTypeMetadataChange = this.onRecordTypeMetadataChange.bind(this);
    this.onBusinessMetadataChange = this.onBusinessMetadataChange.bind(this);
    this.onDisciplineMetadataChange = this.onDisciplineMetadataChange.bind(this);

    this.onSecurityClassificationChange = this.onSecurityClassificationChange.bind(this);
    this.onVitalClassificationChange = this.onVitalClassificationChange.bind(this);
    this.onDocumentStructureChange = this.onDocumentStructureChange.bind(this);

    this.handleExpiryDateChange = this.handleExpiryDateChange.bind(this);
    this.handleRevisionNoChange = this.handleRevisionNoChange.bind(this);
  }

  public render(): React.ReactElement<IPromoteRecordProps> {

    const { isSubmited, IsCancelled, IsMisconfiguration } = this.state;

    if (IsMisconfiguration) {
      return (
        <div className={styles.promoteRecord}>
          Sorry, something went wrong.
          An unexpected error has occurred.
        </div>
      );
    }

    if (IsCancelled) {
      return (
        <div className={styles.promoteRecord}>

        </div>
      );
    }

    if (isSubmited) {
      return (
        <div className={styles.promoteRecord}>
          <div className={styles.container}>
            <div className={styles.row}>
              Thank you, your request will be processed.
            </div>
            <div className={styles.row}>
              <DefaultButton text="Close" onClick={() => this.CancelSubmit()} />
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className={styles.promoteRecord}>
        <div className={styles.container}>
          <div className={styles.row}>
            <TaxonomyPicker allowMultipleSelections={this.state.recordTypeMetadataAllowMulti}
              termsetNameOrID={this.state.recordTypeMetadataTermset}
              required={true}
              panelTitle={this.state.recordTypeMetadataTitle}
              label={this.state.recordTypeMetadataTitle}
              context={this.props.context}
              onChange={this.onRecordTypeMetadataChange}
              errorMessage={(this.state.recordTypeMetadataValue === undefined && this.state.onSubmission) ? this.state.requireMsg : " "}
              onGetErrorMessage={this.validateData.bind(this)}
              isTermSetSelectable={false}
            />
          </div>
          <div className={styles.row}>
            <DateTimePicker label={this.state.ExpiryDateTitle}
              dateConvention={DateConvention.Date}
              timeConvention={TimeConvention.Hours24}
              value={this.state.ExpiryDateValue}
              onChange={this.handleExpiryDateChange}
              showLabels={false}
              isMonthPickerVisible={false}
              formatDate={(date: Date): string => {
                return (date.getMonth() + 1) + '/' + date.getDate() + '/' + (date.getFullYear());
              }} />
          </div>
          <div className={styles.row}>
            <TaxonomyPicker allowMultipleSelections={this.state.businessMetadataAllowMulti}
              termsetNameOrID={this.state.businessMetadataTermset}
              // termsetNameOrID={this.props.businessMetadataTermSetSource}
              // termsetNameOrID="2f82657b-3338-4dea-952b-2d2d1369133b"//"900741-9b68-49a6-8871-c70b30a3cd45"
              required={true}
              panelTitle={this.state.businessMetadataTitle}
              label={this.state.businessMetadataTitle}
              context={this.props.context}
              onChange={this.onBusinessMetadataChange}
              isTermSetSelectable={false}
              errorMessage={(this.state.businessMetadataValue === undefined && this.state.onSubmission) ? this.state.requireMsg : " "}
              onGetErrorMessage={this.validateData.bind(this)}
              validateInput={true}
              // hideTermIds={["98535dd7-ebbe-4929-af2b-0ebfd9dab8de","fc900741-9b68-49a6-8871-c70b30a3cd45", "c9f34c81-45e1-42d5-a955-f2577de467ea"]} // "98535dd7-ebbe-4929-af2b-0ebfd9dab8de",
              // showTermIds={this.state.businessMetadataShowTerms}
              showTermIds={this.props.businessMetadataTermSetSource}
              // hideChildrenOfHiddenParents={true}
              validateOnLoad={true}
            />
          </div>
          <div className={styles.row}>
            <TaxonomyPicker allowMultipleSelections={this.state.disciplineMetadataAllowMulti}
               termsetNameOrID={this.state.disciplineMetadataTermset}
              //termsetNameOrID={this.props.disciplineMetadataTermsetSource}
              required={true}
              panelTitle={this.state.disciplineMetadataTitle}
              label={this.state.disciplineMetadataTitle}
              context={this.props.context}
              onChange={this.onDisciplineMetadataChange}
              validateOnLoad={true}
              isTermSetSelectable={false}
              showTermIds={this.props.disciplineMetadataTermsetSource}
              errorMessage={(this.state.disciplineMetadataValue == undefined && this.state.onSubmission) ? this.state.requireMsg : " "}
            />
          </div>

          <div className={styles.row}>
            <Dropdown placeholder="Select an option"
              label={this.state.sClassificationTitle}
              options={this.state.sClassificationChoices}
              onChange={this.onSecurityClassificationChange}
              required={true}
              onRenderCaretDown={this._onRenderCaretDown}
              errorMessage={!this.state.sClassificationValue && this.state.onSubmission ? this.state.requireMsg : ""}
            />
          </div>

          <div className={styles.row}>
            <Dropdown placeholder="Select an option"
              label={this.state.VitalClassificationTitle}
              options={this.state.VitalClassificationChoices}
              onChange={this.onVitalClassificationChange}
              required={true}
              onRenderCaretDown={this._onRenderCaretDown}
              errorMessage={!this.state.VitalClassificationValue && this.state.onSubmission ? this.state.requireMsg : ""}
            />
          </div>

          <div className={styles.row}>
            <Dropdown placeholder="Select an option"
              label={this.state.DocumentStructureTitle}
              options={this.state.DocumentStructureChoices}
              onChange={this.onDocumentStructureChange}
              required={true}
              onRenderCaretDown={this._onRenderCaretDown}
              errorMessage={!this.state.DocumentStructureValue && this.state.onSubmission ? this.state.requireMsg : ""}
            />
          </div>
          <div className={styles.row}>
            <TextField label={this.state.RevisionNoTitle} onChange={this.handleRevisionNoChange} />
          </div>
          <div className={styles.row}>
            <PeoplePicker
              context={this.props.context}
              groupName={this.state.approversGroupName}
              titleText="Approver"
              personSelectionLimit={5}
              showtooltip={true}
              required={true}
              onChange={this._getPeoplePickerItems}
              showHiddenInUI={false}
              principalTypes={[PrincipalType.User]}
              errorMessage={!this.state.approver && this.state.onSubmission ? this.state.requireMsg : ""}
              resolveDelay={1000} />
          </div>
          <div className={styles.row}>
            <Stack horizontal tokens={stackTokens} styles={stackStyles}>
              <PrimaryButton text="Submit" onClick={() => this.CreateSysRequestItem()} />
              <DefaultButton text="Cancel" onClick={() => this.CancelSubmit()} />
            </Stack>
          </div>
        </div>
      </div>
    );
  }

  public async componentDidMount(): Promise<void> {

    const href: any = new URL(window.location.href);
    const fromUrl = href.searchParams.get("fromSite");
    const docID = href.searchParams.get("docID");
    const listName = href.searchParams.get("listName");

    if (!this.props.SysRecordListPath || !this.props.SysRecordListName || !this.props.ApproversGroupName || !fromUrl || !docID || !listName) {
      this.setState({ IsMisconfiguration: true });
    } else {
      this.setState({ approversGroupName: this.props.ApproversGroupName });
      // groupName for Approver

      let arr = [];
      const ids = docID.split(";");
      ids.map(id => {
        arr.push(id);
      });

      let temp = Web(this.props.SysRecordListPath).lists.getByTitle(this.props.SysRecordListName).fields;
      temp.get().then(async (fields) => {
        this.cfields.map(c => {
          const field = fields.filter(x => x.InternalName == c.name);
          if (field && field.length > 0) {
            let obj = {};

            if (c.select) {
              if (c.type == "choice") {
                let tempVal = [];
                let listVal = field[0][c.select];
                listVal.map(x => {
                  tempVal.push({ key: x, text: x });
                });
                obj[c.state] = tempVal;
              } else {
                obj[c.state] = field[0][c.select];
              }
            }
            obj[c.title] = field[0]["Title"];
            this.setState(obj);
          }
        });

        const businessMetadataShowTerms: string[] = await this.getTermsFromSPList(this.state.businessMetadataTitle);
        this.setState({ businessMetadataShowTerms });
      });

      // try get document file Leaf
      let _fromWeb = Web(fromUrl);
      var filePath = [];
      arr.map((v, i) => {
        var item = _fromWeb.getFileById(v).get().then(rex => {
          filePath.push(rex.ServerRelativeUrl);
        });
      });


      this.setState({ documentIds: filePath });
    }
  }

  private _handleChoices = (item: IDropdownOption): void => {
    this.setState({ sClassificationValue: item });
    //return this.setState({ sClassificationChoice: item });
  }

  private _getPeoplePickerItems(items: any[]) {
    if (items.length == 0) {
      this.setState({ approver: undefined });
    } else {
      Web(this.props.SysRecordListPath).ensureUser(items[0].id).then(u => {
        this.setState({ approver: u.data.Id });
      });
    }
  }

  private onRecordTypeMetadataChange(terms: IPickerTerms) {
    let isvalid = this.setTermValuetoState(terms, "recordTypeMetadataValue");
  }

  private onBusinessMetadataChange(terms: IPickerTerms) {
    let isvalid = this.setTermValuetoState(terms, "businessMetadataValue");
    this.setState({ businessMetadataValid: isvalid });
  }

  private onDisciplineMetadataChange(terms: IPickerTerms) {
    let isvalid = this.setTermValuetoState(terms, "disciplineMetadataValue");
  }

  private onSecurityClassificationChange(event, item: IDropdownOption) {
    this.setState({ sClassificationValue: item });
  }

  private onVitalClassificationChange(event, item: IDropdownOption) {
    this.setState({ VitalClassificationValue: item });
  }

  private onDocumentStructureChange(event, item: IDropdownOption) {
    this.setState({ DocumentStructureValue: item });
  }

  private handleExpiryDateChange(date: Date) {
    if (date) {
      this.setState({ ExpiryDateValue: date });
    } else {
      this.setState({ ExpiryDateValue: null });
    }
  }

  private handleRevisionNoChange(event, value: any) {
    this.setState({ RevisionNoValue: value });
  }

  private setTermValuetoState(terms: IPickerTerms, stateName) {
    let obj = {};

    if (!terms || terms.length == 0) {

      obj[stateName] = undefined;
      this.setState(obj);
      return false;
    }

    let termsString = {
      __metadata: { "type": "SP.Taxonomy.TaxonomyFieldValue" },
      Label: terms[0].name,
      TermGuid: terms[0].key,
      WssId: -1
    };
    //termsString += `-1;#${terms[0].name}|${terms[0].key};#`;
    obj[stateName] = termsString;

    this.setState(obj);

    return true;
  }

  private _onRenderCaretDown = (props: IDropdownProps): JSX.Element => {
    return <Icon iconName="ChevronDown" />;
  }
  private CreateSysRequestItem() {

    if (!this.props.SysRecordListPath) {
      console.log("sysRecordRequest Path is empty!");
      return;
    }

    let isValidData = true;
    this.setState({ onSubmission: true });

    // validate data
    if (this.state.businessMetadataValue === undefined
      || this.state.recordTypeMetadataValue === undefined
      || this.state.disciplineMetadataValue === undefined
    ) {
      isValidData = false;
    }

    if (this.state.DocumentStructureValue === undefined
      || this.state.sClassificationValue === undefined
      || this.state.VitalClassificationValue === undefined
    ) {
      isValidData = false;
    }

    if (this.state.approver === undefined || this.state.ExpiryDateValue === undefined) {
      isValidData = false;
    }

    if (!isValidData)
      console.log("Validation fail.");

    // 
    if (isValidData) {
      const _rweb = Web(this.props.SysRecordListPath);
      let dt = new Date();
      const titleVal = dt.getDate() + "/"
        + (dt.getMonth() + 1) + "/"
        + dt.getFullYear() + " @ "
        + dt.getHours() + ":"
        + dt.getMinutes() + ":"
        + dt.getSeconds();
      _rweb.lists.getByTitle(this.props.SysRecordListName).items.add({
        Title: titleVal,
        DocumentSourceURLs: this.state.documentIds.join(";"),
        ECMS_x0020_Record_x0020_Type: this.state.recordTypeMetadataValue,
        Discipline_x0020_Metadata: this.state.disciplineMetadataValue,
        Business_x0020_Metadata: this.state.businessMetadataValue,
        Security_x0020_Classification: this.state.sClassificationValue.key,
        VitalClassification: this.state.VitalClassificationValue.key,
        DocumentStructure: this.state.DocumentStructureValue.key,
        RevisionNo: this.state.RevisionNoValue,
        ExpiryDate: this.state.ExpiryDateValue,
        ApproverId: this.state.approver,
        RecordStatus: "Submitted"
      }).then(result => {
        this.setState({ isSubmited: true, onSubmission: false });
      });
    }

  }

  private CancelSubmit() {
    this.setState({ IsCancelled: true, onSubmission: false });
    window.close();
  }

  private validateData(value): string {
    if (value === null || (value && value.length == 0)) {
      return "You can't leave this blank.";
    }

    return " ";
  }

  private getTermsFromSPList = (termStoreTitle: string): Promise<string[]> => {
    return new Promise<string[]>((resolve, reject) => {
      try {
        sp.web.lists.getByTitle("Promote Record Term Mappings").items
          .filter(`Title eq '${termStoreTitle}'`)
          .select('Title', 'TermMappings')
          .get()
          .then((items) => {
            let terms: string[] = [];
            if (items && items.length > 0) {
              const termStoreTerms: string = items[0].TermMappings;
              terms = termStoreTerms != null ? termStoreTerms.split(";").map((t: string) => t.trim()) : [];
            }
            resolve(terms);
          })
          .catch(e => { console.error(e); reject(e); });
      } catch (e) {
        console.error(e);
        reject(e);
      }
    });
  }
}
