import * as React from 'react';
import { Spinner, SpinnerSize } from 'office-ui-fabric-react/lib/Spinner';
import { ITermParentProps, ITermParentState } from './ITaxonomyPicker';
import { ITerm } from '../../services/ISPTermStorePickerService';
import { EXPANDED_IMG, COLLAPSED_IMG, TERMSET_IMG, TERM_IMG } from './TaxonomyPicker';
import Term from './Term';

import styles from './TaxonomyPicker.module.scss';
import { Checkbox } from 'office-ui-fabric-react/lib/Checkbox';
import * as strings from 'ControlStrings';

/**
 * Term Parent component, represents termset or term if anchorId
 */
export default class TermParent extends React.Component<ITermParentProps, ITermParentState> {

    private _terms: ITerm[];
    private _anchorName: string;

    constructor(props: ITermParentProps) {
        super(props);

        this._terms = this.props.termset.Terms;
        this.state = {
            loaded: true,
            expanded: true
        };
        this._handleClick = this._handleClick.bind(this);
    }

    /**
     * componentWillMount
     */
    public componentWillMount() {
        // fix term depth if anchroid for rendering
        if (this.props.anchorId) {
            const anchorTerm = this._terms.filter(t => t.Id.toLowerCase() === this.props.anchorId.toLowerCase()).shift();
            if (anchorTerm) {
                // Append ';' separator, as a suffix to anchor term path.
                const anchorTermPath = `${anchorTerm.PathOfTerm};`;
                this._anchorName = anchorTerm.Name;
                let anchorTerms: ITerm[] = this._terms.filter(t => t.PathOfTerm.substring(0, anchorTermPath.length) === anchorTermPath && t.Id !== anchorTerm.Id);

                anchorTerms = anchorTerms.map(term => {
                    term.PathDepth = term.PathDepth - anchorTerm.PathDepth;

                    return term;
                });

                this._terms = anchorTerms;
            }
        }
    }


    /**
     * Handle the click event: collapse or expand
     */
    private _handleClick() {
        this.setState({
            expanded: !this.state.expanded
        });
    }


    /**
     * The term set selection changed
     */
    private termSetSelectionChange = (ev: React.FormEvent<HTMLElement>, isChecked: boolean): void => {
        this.props.termSetSelectedChange(this.props.termset, isChecked);
    }


    /**
     * Default React render method
     */
    public render(): JSX.Element {
        // Specify the inline styling to show or hide the termsets
        const styleProps: React.CSSProperties = {
            display: this.state.expanded ? 'block' : 'none'
        };

        let termElm: JSX.Element = <div />;

        // Check if the terms have been loaded
        if (this.state.loaded) {
            if (this._terms.length > 0) {
                let disabledPaths = [];
                let hiddenPaths = [];
                termElm = (
                    <div style={styleProps}>
                        {
                            this._terms.map(term => {
                                let disabled = false;
                                if (this.props.disabledTermIds && this.props.disabledTermIds.length > 0) {
                                    // Check if the current term ID exists in the disabled term IDs array
                                    disabled = this.props.disabledTermIds.indexOf(term.Id) !== -1;
                                    if (disabled) {
                                        // Push paths to the disabled list
                                        disabledPaths.push(term.PathOfTerm);
                                    }
                                }

                                if (this.props.disableChildrenOfDisabledParents) {
                                    // Check if parent is disabled
                                    const parentPath = disabledPaths.filter(p => term.PathOfTerm.indexOf(p) !== -1);
                                    disabled = parentPath && parentPath.length > 0;
                                }

                                let hidden = false;
                                const parentTerm: string = this.getParentTerm(term);
                                let showCurrentTerm: boolean = true;
                                if (this.props.showTermIds && this.props.showTermIds.length > 0) {
                                    // Check if the current term ID exists in the enabled term IDs array
                                    showCurrentTerm = this.props.showTermIds.filter(p => parentTerm === p).length > 0;
                                    hidden = !showCurrentTerm;
                                    // if (!showTerm) {
                                    //     // Push paths to the disabled list
                                    //     hiddenPaths.push(term.PathOfTerm);
                                    // }
                                }

                                if (this.props.hideTermIds && this.props.hideTermIds.length > 0) {
                                    // Check if the current term ID exists in the disabled term IDs array
                                    hidden = this.props.hideTermIds.indexOf(term.Id) !== -1;
                                    if (hidden) {
                                        // Push paths to the disabled list
                                        hiddenPaths.push(term.PathOfTerm);
                                    }
                                }

                                if (this.props.hideChildrenOfHiddenParents) {
                                    // Check if parent is disabled
                                    const parentPath = hiddenPaths.filter(p => term.PathOfTerm.indexOf(p) !== -1);
                                    hidden = parentPath && parentPath.length > 0;
                                }

                                return (
                                    hidden
                                        ? <React.Fragment />
                                        : <Term key={term.Id}
                                            term={term}
                                            termset={this.props.termset.Id}
                                            activeNodes={this.props.activeNodes}
                                            changedCallback={this.props.changedCallback}
                                            multiSelection={this.props.multiSelection}
                                            disabled={disabled}
                                            termActions={this.props.termActions}
                                            updateTaxonomyTree={this.props.updateTaxonomyTree}
                                            spTermService={this.props.spTermService} />
                                );
                            })
                        }
                    </div>
                );
            } else {
                termElm = <div className={`${styles.listItem} ${styles.term}`}>{strings.TaxonomyPickerNoTerms}</div>;
            }
        } else {
            termElm = <Spinner size={SpinnerSize.medium} />;
        }


        return (
            <div>
                <div className={`${styles.listItem} ${styles.termset} ${(!this.props.anchorId && this.props.isTermSetSelectable) ? styles.termSetSelectable : ""}`} onClick={this._handleClick}>
                    <img src={this.state.expanded ? EXPANDED_IMG : COLLAPSED_IMG} alt={strings.TaxonomyPickerExpandTitle} title={strings.TaxonomyPickerExpandTitle} />
                    {
                        // Show the termset selection box
                        (!this.props.anchorId && this.props.isTermSetSelectable) &&
                        <Checkbox className={styles.termSetSelector}
                            checked={this.props.activeNodes.filter(a => a.path === "" && a.key === a.termSet).length >= 1}
                            onChange={this.termSetSelectionChange} />
                    }
                    <img src={this.props.anchorId ? TERM_IMG : TERMSET_IMG} alt={strings.TaxonomyPickerMenuTermSet} title={strings.TaxonomyPickerMenuTermSet} />
                    {
                        this.props.anchorId ?
                            this._anchorName :
                            this.props.termset.Name
                    }
                </div>
                <div style={styleProps}>
                    {termElm}
                </div>
            </div>
        );
    }

    private getParentTerm = (term: ITerm): string => {
        const pathOfTerm: string = term.PathOfTerm;
        // const pathDepth: number = term.PathDepth;
        return pathOfTerm.split(";")[0];
    }
}