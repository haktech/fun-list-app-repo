﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace CopyMoveReplaceSPDocs
{
    public class SharePointDocManagement
    {
        ClientContext clientContext;
        string tenantURL = "";
        public SharePointDocManagement(string username, string password,string url, string tenantURL)
        {
            SecureString securePassWord = new SecureString();
            foreach (char c in password.ToCharArray()) securePassWord.AppendChar(c);
            clientContext = new ClientContext(url);
            clientContext.Credentials = new SharePointOnlineCredentials(username, securePassWord);
            Web web = clientContext.Web;
            clientContext.Load(web);
            clientContext.ExecuteQuery();
            this.tenantURL = tenantURL;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="SrcUrl">Complete Source URL</param>
        /// <param name="DestUrl">Complete Destionation URL</param>
        public void CopyFile(string srcUrl, string destUrl)
        {
            MoveCopyOptions option = new MoveCopyOptions();
            option.KeepBoth = false;
            MoveCopyUtil.CopyFile(clientContext, srcUrl, destUrl, true, option);
            clientContext.ExecuteQuery();
        }

        private string GetServerRelativeUrl(string filePath)
        {
            return filePath.Replace(tenantURL, "");
        }

        public void ReplaceFile(string fileUrl,string destUrl)
        {
            var file = clientContext.Web.GetFileByServerRelativeUrl(GetServerRelativeUrl(fileUrl));
            clientContext.Load(file);

            clientContext.ExecuteQuery();
            ListItem item = file.ListItemAllFields;
            clientContext.Load(item);
            clientContext.ExecuteQuery();
            var fileDirRef = file.ListItemAllFields["FileDirRef"].ToString();
            
            FileCreationInformation itemCreateInfo = new FileCreationInformation();
            itemCreateInfo.Overwrite = true;
            itemCreateInfo.Url = fileUrl;
            itemCreateInfo.Content = Encoding.ASCII.GetBytes("[InternetShortcut]\nURL=" + destUrl);
            Folder newFolder = clientContext.Web.GetFolderByServerRelativeUrl(fileDirRef);
            var newItem = newFolder.Files.Add(itemCreateInfo);
            
            clientContext.Load(newItem);


            clientContext.ExecuteQuery();
        }
        public void RenameFile(string fileUrl)
        {
            var file = clientContext.Web.GetFileByUrl(fileUrl);
            clientContext.Load(file);
            clientContext.Load(file.ListItemAllFields);

            clientContext.ExecuteQuery();

            string newFilename = fileUrl + ".url"; //dirty hack :)
            file.MoveTo(newFilename, MoveOperations.Overwrite);

            clientContext.ExecuteQuery();
        }

    }
}
