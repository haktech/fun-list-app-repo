﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyMoveReplaceSPDocs
{
    class Program
    {
        static void Main(string[] args)
        {
            string username = "";
            string password = "";
            string tenantURL = "https://petronas.sharepoint.com";

            string sourceFile = "https://petronas.sharepoint.com/sites/ECM_Sandbox/Engineering/Administrative/01 Mechanical/Doc20210320_1627.docx";
            string destinationFile = "https://petronas.sharepoint.com/sites/recordcenter-test/ecm_sandbox/Engineering/Administrative/01 Mechanical/Doc20210320_1627.docx";

            //Connect to Record Center
            SharePointDocManagement spm1 = new SharePointDocManagement(username, password, "https://petronas.sharepoint.com/sites/recordcenter-test/ecm_sandbox", tenantURL);
            //Copy the file to record center
            spm1.CopyFile(sourceFile, destinationFile);

            //Connect to CMS
            SharePointDocManagement spm = new SharePointDocManagement(username, password, "https://petronas.sharepoint.com/sites/ECM_Sandbox/Engineering", tenantURL);
            
            //Replace file with Link content
            spm.ReplaceFile(sourceFile, destinationFile);
            
            //rename the file extension
            spm.RenameFile(sourceFile);

        }
         
    }
}
