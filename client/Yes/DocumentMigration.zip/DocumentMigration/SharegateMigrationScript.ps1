﻿Import-Module Sharegate
$csvFile = "C:\testing script\mapping.csv"
$table = Import-Csv $csvFile -Delimiter ","

$Credentials = Get-Credential

$srcConnection = Connect-Site -Url "https://epecm.petronas.com.my/sites/Sabah" -Credential $Credentials
$dstConnection = Connect-Site -Url "https://petronas.sharepoint.com/sites/ecm_sandbox3" -Browser

$copysettings = New-CopySettings -OnContentItemExists IncrementalUpdate

Set-Variable srcList, dstList,srcSite,dstSite
foreach ($row in $table) {

    Clear-Variable srcList
    Clear-Variable dstList
    Clear-Variable srcSite
    Clear-Variable dstSite

    $srcSite = Connect-Site -Url $row.srcSite -UseCredentialsFrom $srcConnection
    $dstSite = Connect-Site -Url $row.dstSite -UseCredentialsFrom $dstConnection
    

    $srcList = Get-List -Site $srcSite -name $row.SourceSiteList 
    $dstList = Get-List -Site $dstSite -name $row.DestinationSiteList
    
    $mappingSettings = Import-ContentTypeMapping -Path "C:\testing script\ContentTypeMappings-Management.sgctm"
    $mappingSettings = Import-ContentTypeMapping -MappingSettings $mappingSettings -Path "C:\testing script\ContentTypeMappings-DAL.sgctm"
    $mappingSettings = Import-ContentTypeMapping -MappingSettings $mappingSettings -Path "C:\testing script\ContentTypeMappings-Administrative.sgctm"
    $mappingSettings = Import-ContentTypeMapping -MappingSettings $mappingSettings -Path "C:\testing script\ContentTypeMappings-Reference.sgctm"
    $mappingSettings = Import-ContentTypeMapping -MappingSettings $mappingSettings -Path "C:\testing script\ContentTypeMappings-Correspondence.sgctm"
    $mappingSettings = Import-ContentTypeMapping -MappingSettings $mappingSettings -Path "C:\testing script\ContentTypeMappings-Governance.sgctm"
    $mappingSettings

    Import-PropertyTemplate   -Path "C:\testing script\Sharegate default.sgt" -List $dstList -Overwrite 

    $result = Copy-Content -SourceList $srcList -DestinationList $dstList -SourceFolder $row.SourceFolder  -DestinationFolder $row.DestinationFolder -TaskName $row.TaskName -MappingSettings $mappingSettings -CopySettings $copysettings -TemplateName "ECMS template"
    Export-Report -CopyResult $result -Path $row.CopyResultPath -Overwrite
}

