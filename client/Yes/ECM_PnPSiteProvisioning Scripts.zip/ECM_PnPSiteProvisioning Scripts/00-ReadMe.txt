Please follow the folder and PS file sequence for site provisioning
01 – Update the sitecollection
02 – Create Sites (This script will create Subsites, confidential and Record Center sites)
03 – Add Top Navigation
04 – Update SiteCollection Landing Page 
05 – Update Sites Landing Page (All Subsites, but excluded Confidential and Record Center)
06 – Disable Permission Request
07 – Offline Client Availability
08 – Add Apps to sitecollection and subsites (excluded confidential and Record Center)
09 – Add Owners (excluded confidential)
10_11-Create Confidence Lib ( If confidential lib is part of migration)
10_12-AddCLRequest ( If confidential lib is part of migration)
10_13-Final Set MajorVersion (once migration complete, needs to set the majorversion for all lib.)
