﻿Clear-host
   
 
  $Locale = 1033 #English
  $Template = "STS#3" #Team site
   $Description=""
$webUrl = "https://petronas.sharepoint.com/sites/ecm_pdt_grt/confidential"
 
 
 $password = (ConvertTo-SecureString -AsPlainText 'pass@word1' -Force)
 
 
try {
#$webUrl = $value.SiteColURL.Trim()+"/confidential"
   Write-Host  $webUrl
 
        Connect-PnPOnline -Url $webUrl -ClientId 9fd76264-2ca2-4c46-ac8d-7f9e3116526a -CertificatePath '.\protected.pfx' -CertificatePassword $password  -Tenant 3b2e8941-7948-4131-978a-b2dfc7295091
 
Set-PnPField -List "sysCLRequest" -Identity "Title" -Values @{ValidationFormula=  '=AND(IF(ISERROR(FIND(",",Title)),TRUE),IF(ISERROR(FIND("&",Title)),TRUE),IF(ISERROR(FIND(";",Title)),TRUE),IF(ISERROR(FIND("[",Title)),TRUE),IF(ISERROR(FIND("+",Title)),TRUE),IF(ISERROR(FIND(":",Title)),TRUE),IF(ISERROR(FIND(")",Title)),TRUE),IF(ISERROR(FIND("*",Title)),TRUE),IF(ISERROR(FIND("(",Title)),TRUE),IF(ISERROR(FIND("$",Title)),TRUE),IF(ISERROR(FIND("%",Title)),TRUE),IF(ISERROR(FIND("~",Title)),TRUE),IF(ISERROR(FIND("#",Title)),TRUE),IF(ISERROR(FIND("]",Title)),TRUE),IF(ISERROR(FIND(".",Title)),TRUE),IF(ISERROR(FIND("!",Title)),TRUE),IF(ISERROR(FIND("@",Title)),TRUE),IF(ISERROR(FIND("/",Title)),TRUE),IF(ISERROR(FIND("\",Title)),TRUE),IF(ISERROR(FIND("''",Title)),TRUE),IF(ISERROR(FIND("""",Title)),TRUE))';ValidationMessage="Special characters are not allowed.";Indexed = $True;EnforceUniqueValues = $True}
}
catch {
   Write-Output $_.Exception.Message 
  $TargetURL + " " + $_.Exception.Message # | Out-File -FilePath $logPath -Append
}
 