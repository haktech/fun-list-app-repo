﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;

namespace daemon_console.data
{
    public class ExcelWriter 
    {
        Dictionary<int, string> excelSheetColumnNames = new Dictionary<int, string>
        {
            {0,"A" },{1,"B" },{2,"C" },{3,"D" },{4,"E" },{5,"F" },{6,"G" },{7,"H" },{8,"I" },{9,"J" },{10,"K" },
            {11,"L" },{12,"M" },{13,"N" },{14,"O" },{15,"P" },{16,"Q" },{17,"R" },{18,"S" },{19,"T" }
            ,{20,"U" },{21,"V" },{22,"W" },{23,"X" },{24,"Y" },{25,"Z" }
        };
        void AddExcelColumn(ExcelWorksheet workSheet, int rowIndex, int columnIndex, object value)
             => workSheet.Cells[$"{excelSheetColumnNames[columnIndex]}{rowIndex}"].Value = value;
        int AddRow(ExcelWorksheet workSheet, DataTable dataTable, int rowIndex)
        {
            var i = 0;
            foreach (var columName in dataTable.Columns)
            {
                if (columName.ToString() == "Column1")
                {
                    AddExcelColumn(workSheet, rowIndex, i, "");
                }
                else
                {
                    AddExcelColumn(workSheet, rowIndex, i, columName.ToString());
                }

                i++;
            }
            return i;
        }
        void addHeaderRow(ExcelWorksheet workSheet, DataTable dataTable)
        {
            var i = this.AddRow(workSheet, dataTable, 1);
            workSheet.Cells[$"A1:{excelSheetColumnNames[i - 1]}1"].Style.Font.Bold = true;
        }
        void AddTableValueRow(ExcelWorksheet workSheet, DataTable dataTable)
        {
            var rowIndex = 2;
            foreach (DataRow dataRow in dataTable.Rows)
            {
                var i = 0;
                foreach (var columName in dataTable.Columns)
                {
                    AddExcelColumn(workSheet, rowIndex, i, dataRow[columName.ToString()]);
                    i++;
                }
                rowIndex++;
            }
        }
        public void CreateSpreadSheet(DataTable dataTable, string spreadSheetPath, string sheetName)
        {
            Console.WriteLine("Writing to excel sheet starting");
            var spreadSheetFileInfo = new FileInfo(spreadSheetPath);
            using (var excelPackage = new ExcelPackage(spreadSheetFileInfo))
            {
                var workSheet = excelPackage.Workbook.Worksheets[sheetName];
                if (workSheet == null)
                {
                    workSheet = excelPackage.Workbook.Worksheets.Add(sheetName);
                }
                this.addHeaderRow(workSheet, dataTable);
                this.AddTableValueRow(workSheet, dataTable);
                excelPackage.Save();
             }
            Console.WriteLine("Writing to excel sheet completed");

        }
    }
}
