﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace daemon_console.data.Model
{
    public class SharepointSiteDbContext:DbContext
    {
      
    }
}
