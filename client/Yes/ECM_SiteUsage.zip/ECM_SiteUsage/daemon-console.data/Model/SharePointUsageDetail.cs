﻿using System;
using System.Collections.Generic;
using System.Text;

namespace daemon_console.data.Model
{
    public class SharePointUsageDetail
    {
        public int Id { get; set; }
        public Nullable<DateTime> ReportRefreshDate { get; set; }
        public string SiteId { get; set; }
        public string SiteUrl { get; set; }
        public string OwnerDisplayName { get; set; }
        public Nullable<bool> IsDeleted { get; set; }
        public Nullable<DateTime> LastActivityDate { get; set; }
        public Nullable<int> FileCount { get; set; }
        public Nullable<int> ActivityFileCount { get; set; }
        public Nullable<int> PageViewCount { get; set; }
        public Nullable<int> VisitedPageCount { get; set; }
        public Nullable<byte> StorageUsed { get; set; }
        public Nullable<byte> StorageAllocated { get; set; }
        public string RootWebTemplate { get; set; }
        public string OwnerPrincipleName { get; set; }
        public Nullable<int> ReportPeriod { get; set; }
    }
}
