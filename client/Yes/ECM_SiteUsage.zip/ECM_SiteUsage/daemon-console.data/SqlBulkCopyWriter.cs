﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace daemon_console.data
{
    public class SqlBulkCopyWriter
    {
       public void Delete(DateTime refreashDate, string connectionString)
        {
            using (var sqlConnection =
                 new SqlConnection(connectionString))
            {
                sqlConnection.Open();
                using (var command = new SqlCommand())
                {
                    command.CommandType = CommandType.Text;
                    command.CommandText = @"DELETE from[dbo].[SharePointUsageDetail]
                where Month(Convert(Date, ReportRefreshDate))= @month AND Year(Convert(Date, ReportRefreshDate))= @year";
                    command.Parameters.Add(new SqlParameter("@month", refreashDate.Month));
                    command.Parameters.Add(new SqlParameter("@year", refreashDate.Year));
                    command.Connection = sqlConnection;
                    command.ExecuteNonQuery();
                }
            }
        }
        public void Write(DataTable dt, string connectionString)
        {
            Console.WriteLine("Start Writing to Database");
            using (var destinationConnection =
                  new SqlConnection(connectionString))
            {
                destinationConnection.Open();

                using (SqlBulkCopy bulkCopy =
                           new SqlBulkCopy(destinationConnection))
                {
                    bulkCopy.DestinationTableName =
                        "dbo.SharePointUsageDetail";

                    try
                    {
                        foreach (DataColumn column in dt.Columns)
                        {
                            bulkCopy.ColumnMappings.Add(column.ColumnName, column.ColumnName);
                        }
                        bulkCopy.BatchSize = 50;
                        bulkCopy.WriteToServer(dt.CreateDataReader());

                        Console.WriteLine("Writing to Database Completed Successfully.");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    finally
                    {
                    }
                }


            }
        }
    }
}
