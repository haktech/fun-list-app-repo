﻿using System;
using System.Collections.Generic;
using System.Text;

namespace daemon_console.data
{
    public static class Extensions
    {
        public static Nullable<DateTime> ToDateTime(this string data)
        {
            if (string.IsNullOrWhiteSpace(data))
            {
                return null;
            }
            DateTime dateTime;
            DateTime.TryParse(data, out dateTime);
            return dateTime;
        }
        public static Nullable<int> ToInt(this string data)
        {
            int x;
            int.TryParse(data, out x);
            return x;
        }
        public static Nullable<bool> ToBool(this string data)
        {
            bool x;
            bool.TryParse(data, out x);
            return x;
        }
        public static Nullable<byte> ToByte(this string data)
        {
            byte x;
            byte.TryParse(data, out x);
            return x;
        }
    }
}
