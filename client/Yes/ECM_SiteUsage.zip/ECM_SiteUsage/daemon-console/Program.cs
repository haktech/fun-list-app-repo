﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using daemon_console.data;
using daemon_console.data.Model;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Identity.Client;
using Microsoft.Identity.Web;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates; //Only import this if you are using certificate
using System.Threading.Tasks;

namespace daemon_console
{
    /// <summary>
    /// This sample shows how to query the Microsoft Graph from a daemon application
    /// which uses application permissions.
    /// For more information see https://aka.ms/msal-net-client-credentials
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                RunAsync().GetAwaiter().GetResult();
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(ex.Message);
                Console.ResetColor();
            }

            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }

        private static async Task RunAsync()
        {
            AuthenticationConfig config = AuthenticationConfig.ReadFromJsonFile("appsettings.json");

            // You can run this sample using ClientSecret or Certificate. The code will differ only when instantiating the IConfidentialClientApplication
            bool isUsingClientSecret = AppUsesClientSecret(config);

            // Even if this is a console application here, a daemon application is a confidential client application
            IConfidentialClientApplication app;

            if (isUsingClientSecret)
            {
                app = ConfidentialClientApplicationBuilder.Create(config.ClientId)
                    .WithClientSecret(config.ClientSecret)
                    .WithAuthority(new Uri(config.Authority))
                    .Build();
            }

            else
            {
                X509Certificate2 certificate = ReadCertificate(config.CertificateName);
                app = ConfidentialClientApplicationBuilder.Create(config.ClientId)
                    .WithCertificate(certificate)
                    .WithAuthority(new Uri(config.Authority))
                    .Build();
            }

            // With client credentials flows the scopes is ALWAYS of the shape "resource/.default", as the 
            // application permissions need to be set statically (in the portal or by PowerShell), and then granted by
            // a tenant administrator. 
            string[] scopes = new string[] { $"{config.ApiUrl}.default" };

            AuthenticationResult result = null;
            try
            {
                result = await app.AcquireTokenForClient(scopes)
                    .ExecuteAsync();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Token acquired");
                Console.ResetColor();
            }
            catch (MsalServiceException ex) when (ex.Message.Contains("AADSTS70011"))
            {
                // Invalid scope. The scope has to be of the form "https://resourceurl/.default"
                // Mitigation: change the scope to be as expected
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Scope provided is not supported");
                Console.ResetColor();
            }

            if (result != null)
            {
                var httpClient = new HttpClient();
                var apiCaller = new ProtectedApiCallHelper(httpClient);///reports/getSharePointSiteUsageSiteCounts(period='{period_value}'
                await apiCaller.CallWebApiAndProcessResultASync($"{config.ApiUrl}v1.0/reports/getSharePointSiteUsageDetail(period='D30')", result.AccessToken, config, Display);
            }
        }

        /// <summary>
        /// Display the result of the Web API call
        /// </summary>
        /// <param name="result">Object to display</param>
        private static void Display(string result, AuthenticationConfig config)
        {
            var dt = new DataTable();
            dt.Columns.Add("ReportRefreshDate");
            dt.Columns.Add("SiteId");
            dt.Columns.Add("SiteUrl");
            dt.Columns.Add("OwnerDisplayName");
            dt.Columns.Add("IsDeleted");
            dt.Columns.Add("LastActivityDate");
            dt.Columns.Add("FileCount");
            dt.Columns.Add("ActivityFileCount");
            dt.Columns.Add("PageViewCount");
            dt.Columns.Add("VisitedPageCount");
            dt.Columns.Add("StorageUsed");
            dt.Columns.Add("StorageAllocated");
            dt.Columns.Add("RootWebTemplate");
            dt.Columns.Add("OwnerPrincipleName");
            dt.Columns.Add("ReportPeriod");
            var jsonArray = result.Split(Environment.NewLine,
                             StringSplitOptions.RemoveEmptyEntries);
            var items = new List<SharePointUsageDetail>();

            if (jsonArray.Length > 0)
            {
                bool isHeaderRow = true;
                foreach (var item in jsonArray)
                {
                    if (!isHeaderRow)
                    {
                        var data = item.Split(',');
                        if (data.Length > 0)
                        {
                            if (!string.IsNullOrWhiteSpace(data[2]) && data[2].Contains("sites/ecm"))
                            {
                                var drow = dt.NewRow();

                                drow["ReportRefreshDate"] = data[0];
                                drow["SiteId"] = data[1];
                                drow["SiteUrl"] = data[2];

                                drow["OwnerDisplayName"] = data[3];
                                drow["IsDeleted"] = data[4];
                                drow["LastActivityDate"] = data[5];
                                drow["FileCount"] = data[6];
                                drow["ActivityFileCount"] = data[7];
                                drow["PageViewCount"] = data[8];
                                drow["VisitedPageCount"] = data[9];
                                drow["StorageUsed"] = data[10];
                                drow["StorageAllocated"] = data[11];
                                drow["RootWebTemplate"] = data[12].ToString();
                                drow["OwnerPrincipleName"] = data[13].ToString();
                                drow["ReportPeriod"] = data[14];
                                dt.Rows.Add(drow);
                            }
                        }
                    }
                    isHeaderRow = false;
                }
                DateTime? refreshDate = null;
                foreach (DataRow row in dt.Rows)
                {
                    refreshDate = row["ReportRefreshDate"].ToString().ToDateTime();
                    if (refreshDate.HasValue)
                    {
                        break;
                    }
                }
                var sqlBulCopyWriter = new SqlBulkCopyWriter();
                if (refreshDate.HasValue)
                {
                    sqlBulCopyWriter.Delete(refreshDate.Value, config.DbConnectionString);
                }
                sqlBulCopyWriter.Write(dt, config.DbConnectionString);
               // new ExcelWriter().CreateSpreadSheet(dt, config.FilePath, "Site Usage Details");
            }

        }




        /// <summary>
        /// Checks if the sample is configured for using ClientSecret or Certificate. This method is just for the sake of this sample.
        /// You won't need this verification in your production application since you will be authenticating in AAD using one mechanism only.
        /// </summary>
        /// <param name="config">Configuration from appsettings.json</param>
        /// <returns></returns>
        private static bool AppUsesClientSecret(AuthenticationConfig config)
        {
            string clientSecretPlaceholderValue = "[Enter here a client secret for your application]";
            string certificatePlaceholderValue = "[Or instead of client secret: Enter here the name of a certificate (from the user cert store) as registered with your application]";

            if (!String.IsNullOrWhiteSpace(config.ClientSecret) && config.ClientSecret != clientSecretPlaceholderValue)
            {
                return true;
            }

            else if (!String.IsNullOrWhiteSpace(config.CertificateName) && config.CertificateName != certificatePlaceholderValue)
            {
                return false;
            }

            else
                throw new Exception("You must choose between using client secret or certificate. Please update appsettings.json file.");
        }

        private static X509Certificate2 ReadCertificate(string certificateName)
        {
            if (string.IsNullOrWhiteSpace(certificateName))
            {
                throw new ArgumentException("certificateName should not be empty. Please set the CertificateName setting in the appsettings.json", "certificateName");
            }
            CertificateDescription certificateDescription = CertificateDescription.FromStoreWithDistinguishedName(certificateName);
            DefaultCertificateLoader defaultCertificateLoader = new DefaultCertificateLoader();
            defaultCertificateLoader.LoadIfNeeded(certificateDescription);
            return certificateDescription.Certificate;
        }
    }
}
