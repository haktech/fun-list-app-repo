﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECM_DeclareRecordRevampConsole
{
    public class QueueMessagePL
    {

        public string ItemID { get; set; }
        public string ListName { get; set; }
        public string DocumentSourceURLs { get; set; }
        public string SiteURL { get; set; }
    }
}
