﻿using Microsoft.Identity.Client;
using System;
using System.Configuration;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;

namespace ConfidetialLibraryRequestJob
{
    public class TokenProvider
    {
        public static async Task<string> GetAccessTokenAsync(string endpoint)
        {
            var reader = new AppSettingsReader();

            var clientId = reader.GetValue("ClientID", typeof(String)) as String;
            var tenantId = reader.GetValue("TenantID", typeof(String)) as String;
            var certPassword = reader.GetValue("CertPassword", typeof(String)) as String;
            var certFile = reader.GetValue("CertFile", typeof(String)) as String;

            using var certificate = GetCertificate(
                Path.Combine(Environment.CurrentDirectory, certFile),
                certPassword);

            var confidentialClient = ConfidentialClientApplicationBuilder
                .Create(clientId)
                .WithTenantId(tenantId)
                .WithCertificate(certificate)
                .Build();

            var token = await confidentialClient
                .AcquireTokenForClient(new[] { $"{endpoint.TrimEnd('/')}/.default" })
                .ExecuteAsync();

            return token.AccessToken;
        }

        private static X509Certificate2 GetCertificate(string path, string password)
        {
            return new X509Certificate2(path, password, X509KeyStorageFlags.MachineKeySet);
        }
    }
}