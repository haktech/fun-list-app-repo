using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Client;
using Microsoft.SharePoint.Client;
using System.Security.Cryptography.X509Certificates;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage.Queue;
using Microsoft.WindowsAzure.Storage;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace ECM_ConfidetialLibraryRequestAzFunc
{
    public static class GetConfidentialSites
    {
        public static string ecmURL = "";
        public static string configListName = "";
        [FunctionName("GetConfidentialSites")]
        public static async Task RunAsync([TimerTrigger("%TimerInterval%",RunOnStartup =false)] TimerInfo myTimer, ILogger log, ExecutionContext _context)
        {
            
            InitVariables();
             var token = await TokenProviderByCertThumbPrint.getAuthendicatedToken();

            var objAzFncPL = new AzFncPL();
            using var context = new ClientContext(ecmURL);
            context.ExecutingWebRequest += (sender, e) =>
            {
                e.WebRequestExecutor.RequestHeaders["Authorization"] = "Bearer " + token;
            };
            GetConfidentialSitesURL(context, _context);
        }
        private static void InitVariables()
        {
            ecmURL = Environment.GetEnvironmentVariable("EcmURL");
            configListName = Environment.GetEnvironmentVariable("configListName");
        }
        private static void GetConfidentialSitesURL(ClientContext clientContext, ExecutionContext _context)
        {
            try
            {
                List targetList = clientContext.Web.Lists.GetByTitle(configListName);
                clientContext.Load(targetList);
                clientContext.ExecuteQuery();

                CamlQuery oQuery = CamlQuery.CreateAllItemsQuery();

                ListItemCollection oCollection = targetList.GetItems(oQuery);
                clientContext.Load(oCollection);
                clientContext.ExecuteQuery();

                Process_QueueMessage(oCollection);
            }
            catch
            {
                throw;
            }
        }

        private static void Process_QueueMessage(ListItemCollection oCollection)
        {
            // Parse the connection string   
            // Return a reference to the storage account.  
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(Environment.GetEnvironmentVariable("AzureWebJobsStorage"));
            //StorageConnectionString

            // Create the queue client.  
            CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();

            // Retrieve queue reference from the container  
            CloudQueue queue = queueClient.GetQueueReference("confidentialsitesqueue");

            // Create queue if it does not exist  
            queue.CreateIfNotExistsAsync();

            foreach (ListItem oItem in oCollection)
            {
                var queueMessage = new List<string>();
                Console.WriteLine("========================================");
                Console.WriteLine("Site: " + oItem["Title"].ToString().Trim());
                string title = oItem["Title"].ToString();
                string id = oItem["ID"].ToString().Trim();
                var data = title;
                queueMessage.Add(data);
                CloudQueueMessage message = new CloudQueueMessage(JsonConvert.SerializeObject(queueMessage));

                //Add message to queue  
                queue.AddMessageAsync(message);
            }
            
        }

    }
}
