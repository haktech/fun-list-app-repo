using System;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Client;
using Microsoft.SharePoint.Client;
using System.Linq;
using System.Collections.Generic;
using Newtonsoft.Json;
using Microsoft.SharePoint.Client.Utilities;

namespace ECM_ConfidetialLibraryRequestAzFunc
{
    public class CreateDocumentLibrarys
    {
        public static string ecmURL = "";
        public static string requestListName = "";
        public static string configListName = "";
        [FunctionName("CreateDocumentLibrarys")]
        public static async Task RunAsync([QueueTrigger("confidentialsitesrequestqueue", Connection = "AzureWebJobsStorage")] string myQueueItem,
           
            ILogger log, ExecutionContext _context)
        {
            log.LogInformation($"C# Queue trigger function processed: {myQueueItem}");
            InitVariables();
            List<QueueMessage> items = JsonConvert.DeserializeObject<List<QueueMessage>>(myQueueItem);
            var token = await TokenProviderByCertThumbPrint.getAuthendicatedToken();

            var site = items.Select(x => x.Site).FirstOrDefault();
            using var context = new ClientContext(site);
            context.ExecutingWebRequest += (sender, e) =>
            {
                e.WebRequestExecutor.RequestHeaders["Authorization"] = "Bearer " + token;
            };
            foreach (var item in items)
            {
                
                CreateDocumentLibrary(context, item.Id, item.Title, item.libOwnerName,item.libSiteAdminApprover);
            }

            log.LogInformation($"C# Queue trigger function processed: {myQueueItem}");
           

        }
        private static void InitVariables()
        {
            ecmURL = Environment.GetEnvironmentVariable("EcmURL");
            requestListName = Environment.GetEnvironmentVariable("requestListName");
            configListName = Environment.GetEnvironmentVariable("configListName"); 
        }
        private static void CreateDocumentLibrary(ClientContext clientContext, string ID, string title, string libOwnerName, string libSiteAdminApprover)
        {
            try
            {

                using (clientContext)
                {
                    // The properties of the new custom list
                    ListCreationInformation creationInfo = new ListCreationInformation();
                    creationInfo.Title = title;
                    creationInfo.Description = "";
                    creationInfo.TemplateType = (int)ListTemplateType.DocumentLibrary;
                    //creationInfo.QuickLaunchOption = QuickLaunchOptions.On;

                    List newList = clientContext.Web.Lists.Add(creationInfo);
                    clientContext.Load(newList);
                    // Execute the query to the server.
                    clientContext.ExecuteQuery();

                    var currentSiteUrl = clientContext.Url;

                    var newListUrl = currentSiteUrl + "/" + title;
                    DeleteExistingContentType(clientContext, ID, title);

                    AddContentType(clientContext, ID, title);

                    AddViewColumn(clientContext, ID, title);

                    SetDocumentLibrarySettings(clientContext, ID, title);

                    CreateLibraryGroups(clientContext, ID, title, libOwnerName);

                    UpdatePermissionGroups(clientContext, ID, title);

                    UpdateRecordStatus(clientContext, ID, title);
                    // Notify requestor
                    SendNotification(clientContext, title, libOwnerName, libSiteAdminApprover, newListUrl);
                }
            }
            catch
            {
                throw;
            }
           
        }

        private static void SendNotification(ClientContext clientContext, string strLibTitle, string libOwnerName, string libSiteAdminApprover, string strListURL)
        {
            User ospOwner = clientContext.Web.EnsureUser(libOwnerName);
            clientContext.Load(ospOwner, u => u.Email, u => u.Title);
            clientContext.ExecuteQuery();

            User ospApprover = clientContext.Web.EnsureUser(libSiteAdminApprover);
            clientContext.Load(ospApprover, u => u.Email, u => u.Title);
            clientContext.ExecuteQuery();
            string msgBody = "Dear " + ospOwner.Title + ",<br><br>This is to inform you that your requested Cofidential Library has been Provisioned.<br><br>Please <a href='" + strListURL + "'>click here</a> to view '" + strLibTitle + "' Library.<br><br>Thank you.<br><br>*This is a system generated notification.";

            using (var EmailclientContext = clientContext)
            {
                var emailprpoperties = new EmailProperties();

                emailprpoperties.To = new List<string> { ospOwner.Email };
                emailprpoperties.From = libSiteAdminApprover;
                emailprpoperties.Body = msgBody;
                emailprpoperties.Subject = strLibTitle + " - Confidential Library has been provisioned";

                Utility.SendEmail(EmailclientContext, emailprpoperties);
                EmailclientContext.ExecuteQuery();
            }
        }

        private static void UpdatePermissionGroups(ClientContext clientContext, string ID, string title)
        {
            using (clientContext)
            {
                // clientcontext.Web.Lists.GetById - This option also can be used to get the list using List GUID
                // This value is NOT List internal name
                List targetList = clientContext.Web.Lists.GetByTitle(title);

                //Stop Inheritance from parent site
                targetList.BreakRoleInheritance(false, false);

                // Clean up special char in title
                string title_ori = title;
                title = System.Text.RegularExpressions.Regex.Replace(title_ori, @"[^0-9a-zA-Z]+", "_");

                //////////////////////////////////////////
                // Owners
                //////////////////////////////////////////
                string ownersGroupTemp = "C " + title + " Owners";
                string ownersGroup = ownersGroupTemp.Replace(" ", "_").Trim();
                Group group = clientContext.Web.SiteGroups.GetByName(ownersGroup);
                RoleDefinitionBindingCollection roleDefCollection = new RoleDefinitionBindingCollection(clientContext);

                // Set the permission level of the group for this particular list
                //RoleDefinition readDef = clientContext.Web.RoleDefinitions.GetByName("Full Control");
                //RoleDefinition readDef = clientContext.Web.RoleDefinitions.GetByName("Contribute");
                RoleDefinition readDef = clientContext.Web.RoleDefinitions.GetByName("ManagerUsers");
                roleDefCollection.Add(readDef);

                Principal userGroup = group;
                RoleAssignment roleAssign = targetList.RoleAssignments.Add(userGroup, roleDefCollection);

                clientContext.Load(roleAssign);
                roleAssign.Update();
                clientContext.ExecuteQuery();

                //////////////////////////////////////////
                // Members
                //////////////////////////////////////////
                string membersGroupTemp = "C " + title + " Members";
                string membersGroup = membersGroupTemp.Replace(" ", "_").Trim();
                group = clientContext.Web.SiteGroups.GetByName(membersGroup);
                roleDefCollection = new RoleDefinitionBindingCollection(clientContext);

                // Set the permission level of the group for this particular list
                readDef = clientContext.Web.RoleDefinitions.GetByName("Contribute");
                roleDefCollection.Add(readDef);

                userGroup = group;
                roleAssign = targetList.RoleAssignments.Add(userGroup, roleDefCollection);

                clientContext.Load(roleAssign);
                roleAssign.Update();
                clientContext.ExecuteQuery();

                //////////////////////////////////////////
                // Visitors
                //////////////////////////////////////////
                string visitorsGroupTemp = "C " + title + " Visitors";
                string visitorsGroup = visitorsGroupTemp.Replace(" ", "_").Trim();
                group = clientContext.Web.SiteGroups.GetByName(visitorsGroup);
                roleDefCollection = new RoleDefinitionBindingCollection(clientContext);

                // Set the permission level of the group for this particular list
                readDef = clientContext.Web.RoleDefinitions.GetByName("Read");
                roleDefCollection.Add(readDef);

                userGroup = group;
                roleAssign = targetList.RoleAssignments.Add(userGroup, roleDefCollection);

                clientContext.Load(roleAssign);
                roleAssign.Update();
                clientContext.ExecuteQuery();

                //////////////////////////////////////////
                // Remove default user from the list's permission 
                //////////////////////////////////////////
                //User oUser = clientContext.Web.EnsureUser(username);
                //Principal pUser = oUser;
                //targetList.RoleAssignments.GetByPrincipal(pUser).DeleteObject();

            }
        }

        private static void CreateLibraryGroups(ClientContext clientContext, string ID, string title, string libOwnerName)
        {
            using (clientContext)
            {


                // NOTE: The user who is running the code will be added as "Group Ownr"
                GroupCollection oGroupCollection = clientContext.Web.SiteGroups;

                // GroupCreationInformation object
                GroupCreationInformation oGroupCreationInformation = new GroupCreationInformation();

                // Clean up special char in title
                string title_ori = title;
                title = System.Text.RegularExpressions.Regex.Replace(title_ori, @"[^0-9a-zA-Z]+", "_");

                // Owners
                string ownersGroupTemp = "C " + title + " Owners";
                string ownersGroup = ownersGroupTemp.Replace(" ", "_").Trim();
                oGroupCreationInformation.Title = ownersGroup;
                oGroupCreationInformation.Description = "Owners";
                Group oGroup = oGroupCollection.Add(oGroupCreationInformation);
                clientContext.ExecuteQuery();



                // Members
                string membersGroupTemp = "C " + title + " Members";
                string membersGroup = membersGroupTemp.Replace(" ", "_").Trim();
                oGroupCreationInformation.Title = membersGroup;
                oGroupCreationInformation.Description = "Members";
                oGroup = oGroupCollection.Add(oGroupCreationInformation);
                clientContext.ExecuteQuery();

                // Visitors
                string visitorsGroupTemp = "C " + title + " Visitors";
                string visitorsGroup = visitorsGroupTemp.Replace(" ", "_").Trim();
                oGroupCreationInformation.Title = visitorsGroup;
                oGroupCreationInformation.Description = "Visitors";
                oGroup = oGroupCollection.Add(oGroupCreationInformation);
                clientContext.ExecuteQuery();

                ////////////////////////////////////////////////////
                // Set group owners
                ////////////////////////////////////////////////////

                // Set owner for Owners group
                //User oUserOwner = clientContext.Web.EnsureUser(libOwnerName);
                //Group oGroupOwner = clientContext.Web.SiteGroups.GetByName(siteOwnerGroup); // Defined siteOwnerGroup
                // Set owner to created ownersGroup. Ex: C_Test_Owners
                Group oGroupOwner = clientContext.Web.SiteGroups.GetByName(ownersGroup);
                Group oGroupOwners = clientContext.Web.SiteGroups.GetByName(ownersGroup);
                oGroupOwners.Owner = oGroupOwner;
                oGroupOwners.Update();
                clientContext.ExecuteQuery();

                // Set owner for Members group
                Group oGroupMember = clientContext.Web.SiteGroups.GetByName(ownersGroup);
                Group ownerGroupMembers = clientContext.Web.SiteGroups.GetByName(membersGroup);
                ownerGroupMembers.Owner = oGroupMember;
                ownerGroupMembers.Update();
                clientContext.ExecuteQuery();

                // Set owner for Visitors group
                Group oGroupVisitor = clientContext.Web.SiteGroups.GetByName(ownersGroup);
                Group ownerGroupVisitors = clientContext.Web.SiteGroups.GetByName(visitorsGroup);
                ownerGroupVisitors.Owner = oGroupVisitor;
                ownerGroupVisitors.Update();
                clientContext.ExecuteQuery();

                ////////////////////////////////////////////////////
                // Add the user to group owners
                ////////////////////////////////////////////////////
                oGroup = clientContext.Web.SiteGroups.GetByName(ownersGroup);

                // Get user using Logon name
                User oUser = clientContext.Web.EnsureUser(libOwnerName);

                // Add user to the group
                oGroup.Users.AddUser(oUser);
                clientContext.ExecuteQuery();
            }
        }

        private static void SetDocumentLibrarySettings(ClientContext clientContext, string ID, string title)
        {
            using (clientContext)
            {
                // clientcontext.Web.Lists.GetById - This option also can be used to get the list using List GUID
                // This value is NOT List internal name
                List targetList = clientContext.Web.Lists.GetByTitle(title);
                clientContext.Load(targetList);

                // Specify whether this list should be visible in search results.
                // If below parameter is set to "true", the list will not b viible in search results as there will be no crawl action for this list
                targetList.NoCrawl = true;

                // Set Offline Client Availability
                targetList.ExcludeFromOfflineClient = true;

                // Set QuickLaunch
                targetList.OnQuickLaunch = true;

                targetList.Update();
                clientContext.ExecuteQuery();
            }
        }

        private static void AddViewColumn(ClientContext clientContext, string ID, string title)
        {
            using (clientContext)
            {
                // clientcontext.Web.Lists.GetById - This option also can be used to get the list using List GUID
                // This value is NOT List internal name
                List targetList = clientContext.Web.Lists.GetByTitle(title);

                // Get required view by specifying view Title here
                View targetView = targetList.Views.GetByTitle("All Documents");

                // Add View column. You can specify Internal or display name of the column over here
                //targetView.ViewFields.Add("Business GTS");
                //targetView.ViewFields.Add("Discipline GTS");
                targetView.ViewFields.Add("Security Classification");

                targetView.Update();
                clientContext.ExecuteQuery();
            }
        }

        private static void DeleteExistingContentType(ClientContext clientContext, string ID, string title)
        {
            using (clientContext)
            {
                List TargetList = null;

                // clientcontext.Web.Lists.GetById - This option also can be used to get the list using List GUID
                // This value is NOT List internal name
                TargetList = clientContext.Web.Lists.GetByTitle(title);
                clientContext.Load(TargetList);

                // Load List conntent types
                clientContext.Load(TargetList.ContentTypes);
                clientContext.ExecuteQuery();

                // Write Content Type name over here
                string contentTypeName = "Document";

                // Get list content types
                ContentTypeCollection contentTypeCollection = TargetList.ContentTypes;

                // Get target content type from list content types
                ContentType targetContentType = (from contentType in contentTypeCollection where contentType.Name == contentTypeName select contentType).FirstOrDefault();

                // Condition to delete target content type.
                if (targetContentType != null)
                {
                    targetContentType.DeleteObject();
                    TargetList.Update();
                    clientContext.ExecuteQuery();
                }
            }
        }

        private static void AddContentType(ClientContext clientContext, string ID, string title)
        {
            using (clientContext)
            {
                ContentTypeCollection contentTypeCollection;

                // Option - 1 - Get Content Types from Root web
                contentTypeCollection = clientContext.Site.RootWeb.ContentTypes;

                // Option - 2 - Get Content Types from Current web
                //contentTypeCollection = clientContext.Web.ContentTypes;

                clientContext.Load(contentTypeCollection);
                clientContext.ExecuteQuery();

                // Get the content type from content type collection. Give the content type name over here
                ContentType targetContentType = (from contentType in contentTypeCollection where contentType.Name == "ECM Document" select contentType).FirstOrDefault();

                // Add existing content type on target list. Give target list name over here.
                List targetList = clientContext.Web.Lists.GetByTitle(title);
                targetList.ContentTypes.AddExistingContentType(targetContentType);
                targetList.Update();
                clientContext.Web.Update();
                clientContext.ExecuteQuery();
            }
        }

        private static void UpdateRecordStatus(ClientContext clientContext, string ID, string title)
        {
            using (clientContext)
            {
                // Get Doc library ID
                List docLibList = clientContext.Web.Lists.GetByTitle(title);
                clientContext.Load(docLibList);
                clientContext.ExecuteQuery();

                // clientcontext.Web.Lists.GetById - This option also can be used to get the list using List GUID
                // This value is NOT List internal name
                List targetList = clientContext.Web.Lists.GetByTitle(requestListName);

                // Get Item by ID
                ListItem oItem = targetList.GetItemById(int.Parse(ID));

                // Update status
                oItem["Status"] = "Provisioned";

                // Update Manage groups
                FieldUrlValue url = new FieldUrlValue();
                var currentSiteUrl = clientContext.Url;

                url.Url = currentSiteUrl + "/_layouts/15/user.aspx?List=" + docLibList.Id;
                //url.Url = siteURL + "/_layouts/15/user.aspx?List=" + docLibList.Id;
                url.Description = "Manage Permission";
                oItem["ManageGroups"] = url;

                oItem.Update();
                clientContext.ExecuteQuery();

                Console.WriteLine("Document library named '" + title + "' created." + " ID: " + docLibList.Id);
            }
        }

        private static void GetAllList(ClientContext clientContext)
        {
            using (clientContext)
            {
                // clientcontext.Web.Lists.GetById - This option also can be used to get the list using List GUID
                // This value is NOT List internal name
                ListCollection targetlListCollection = clientContext.Web.Lists;

                clientContext.Load(targetlListCollection);
                clientContext.ExecuteQuery();

                // Iterate through each list object
                foreach (List list in targetlListCollection)
                {
                    Console.WriteLine("List Name: " + list.Title);
                }
            }
        }

    }
}
