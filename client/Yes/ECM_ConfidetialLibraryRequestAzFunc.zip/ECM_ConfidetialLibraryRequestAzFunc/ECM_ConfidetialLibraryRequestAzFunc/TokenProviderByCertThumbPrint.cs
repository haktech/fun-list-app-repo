﻿using Microsoft.Identity.Client;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ECM_ConfidetialLibraryRequestAzFunc
{
    public class TokenProviderByCertThumbPrint
    {

        public static async Task<string> getAuthendicatedToken()
        {
            AzFncPL objAzFncPL = new AzFncPL
            {
                 clientID = Environment.GetEnvironmentVariable("ClientID"),
                 tenantID = Environment.GetEnvironmentVariable("TenantID"),
                 CertThumbPrint = Environment.GetEnvironmentVariable("CertThumbPrint"),

            };
            
            var scopes = new string[] { "https://petronas.sharepoint.com/.default" };
            var accessToken = await GetAppAuthedicatedClient(objAzFncPL.clientID, objAzFncPL.CertThumbPrint, scopes, objAzFncPL.tenantID);

            return accessToken;
        }
        internal static async Task<string> GetAppAuthedicatedClient(string clientID, string thumbPrint, string[] scopes, string tenantID)
        {
            X509Certificate2 cert = getAppOnlyCert(thumbPrint);
            IConfidentialClientApplication clientApp = ConfidentialClientApplicationBuilder
                .Create(clientID)
                .WithCertificate(cert)
                .WithTenantId(tenantID)
                .Build();
            AuthenticationResult authResult = await clientApp.AcquireTokenForClient(scopes).ExecuteAsync();
            string strAccessToken = authResult.AccessToken;
            return strAccessToken;
        }
        private static X509Certificate2 getAppOnlyCert(string strThumbPrint)
        {
            X509Certificate2 appOnlyCert = null;
            using (X509Store certStore = new X509Store(StoreName.My, StoreLocation.CurrentUser))
            {
                certStore.Open(OpenFlags.ReadOnly);
                X509Certificate2Collection certCollection = certStore.Certificates.Find(X509FindType.FindByThumbprint, strThumbPrint, false);
                if (certCollection.Count > 0)
                {
                    appOnlyCert = certCollection[0];
                }
                certStore.Close();
                return appOnlyCert;
            }
        }

        public static ClientContext getClientContextwithAuthedication(string siteURL, string accessToken)
        {
            ClientContext oContext = new ClientContext(siteURL);
            oContext.ExecutingWebRequest +=
                delegate (object osender, WebRequestEventArgs e)
                {
                    e.WebRequestExecutor.RequestHeaders["Authorization"] = "Bearer " + accessToken;
                };

            return oContext;
        }
    }
}
