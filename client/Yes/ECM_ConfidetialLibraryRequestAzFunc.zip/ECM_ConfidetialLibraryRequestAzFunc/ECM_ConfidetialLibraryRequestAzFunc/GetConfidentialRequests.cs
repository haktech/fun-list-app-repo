using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Client;
using Microsoft.SharePoint.Client;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using Newtonsoft.Json;

namespace ECM_ConfidetialLibraryRequestAzFunc
{
    public static class GetConfidentialRequests
    {
        public static string ecmURL = "";
        public static string requestListName = "";
        public static ILogger logger;
        [FunctionName("GetConfidentialRequests")]
        public static async Task RunAsync([QueueTrigger("confidentialsitesqueue", Connection = "AzureWebJobsStorage")] string myQueueItem,

            ILogger log, ExecutionContext _context)
        {
            logger = log;
            //SPO functionalities
            InitVariables();
            var sites = JsonConvert.DeserializeObject<List<string>>(myQueueItem);
            sites = sites.ToList();
            var token = await TokenProviderByCertThumbPrint.getAuthendicatedToken();

            foreach (var site in sites)
            {
                using var context = new ClientContext(site);
                context.ExecutingWebRequest += (sender, e) =>
                {
                    e.WebRequestExecutor.RequestHeaders["Authorization"] = "Bearer " + token;
                };
                GetConfidentialRequest(context, site);

                log.LogInformation($"C# Queue trigger function processed: {site}");
            }
            
        }
        private static void InitVariables()
        {
            ecmURL = Environment.GetEnvironmentVariable("EcmURL");
            requestListName = Environment.GetEnvironmentVariable("requestListName");
        }
        private static void GetConfidentialRequest(ClientContext clientContext,string site)
        {
            try
            {
                List targetList = clientContext.Web.Lists.GetByTitle(requestListName);
                clientContext.Load(targetList);
                clientContext.ExecuteQuery();

                // Optioanlly you can use overloaded method CreateAllItemsQuery(int rowlimits, params viewfields): where using "rowlimits" you can limit the number of rows returned and viewfields will return only specified fields in the result set
                // This method will get all the items from all the folders and sub folders including folders and sub folders too
                CamlQuery oQuery = CamlQuery.CreateAllItemsQuery();

                ListItemCollection oCollection = targetList.GetItems(oQuery);
                clientContext.Load(oCollection);
                clientContext.ExecuteQuery();

                int no = 1;
                string libSiteAdminApprover = "";

                var list = new List<QueueMessage>();
                foreach (ListItem oItem in oCollection)
                {
                    // If status = "Approved" then create the document library
                    if (oItem["Status"].ToString() == "Approved")
                    {
                        Console.WriteLine(no + ") " + oItem["Title"].ToString() + " - Status: " + oItem["Status"].ToString());
                        no += 1;

                        //Console.WriteLine("Type: " + oItem["LibraryOwner"].GetType());

                        string libOwnerName = "";

                        if (oItem["LibraryOwner"].GetType().ToString() == "Microsoft.SharePoint.Client.FieldUserValue[]")
                        {
                            FieldUserValue[] user = (FieldUserValue[])oItem["LibraryOwner"];
                            libOwnerName = user[0].LookupValue;
                            Console.WriteLine("LibraryOwnerName: " + libOwnerName);
                        }
                        else
                        {
                            FieldUserValue user = (FieldUserValue)oItem["LibraryOwner"];
                            libOwnerName = user.LookupValue;
                            Console.WriteLine("LibraryOwnerName: " + libOwnerName);
                        }

                        if (oItem["Site_x0020_Admin_x0020_Approver"].GetType().ToString() == "Microsoft.SharePoint.Client.FieldUserValue[]")
                        {
                            FieldUserValue[] user = (FieldUserValue[])oItem["Site_x0020_Admin_x0020_Approver"];
                            libSiteAdminApprover = user[0].LookupValue;
                            Console.WriteLine("Site Admin Approver: " + libSiteAdminApprover);
                        }
                        else
                        {
                            FieldUserValue user = (FieldUserValue)oItem["Site_x0020_Admin_x0020_Approver"];
                            libSiteAdminApprover = user.LookupValue;
                            Console.WriteLine("Site Admin Approver: " + libSiteAdminApprover);
                        }
                        list.Add(new QueueMessage()
                        {
                            Site = site.Trim(),
                            Id = oItem["ID"].ToString().Trim(),
                            libOwnerName = libOwnerName,
                            Title = oItem["Title"].ToString(),
                            libSiteAdminApprover = libSiteAdminApprover
                        });
                    }
                }
                if (list.Count > 0)
                    SendMessageToQueue(list);
            }
            catch
            {
                throw;
            }
        }

        private static void SendMessageToQueue(List<QueueMessage> list)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(Environment.GetEnvironmentVariable("AzureWebJobsStorage"));
            //StorageConnectionString

            // Create the queue client.  
            CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();

            // Retrieve queue reference from the container  
            CloudQueue queue = queueClient.GetQueueReference("confidentialsitesrequestqueue");

            // Create queue if it does not exist  
            queue.CreateIfNotExistsAsync();
            //Create message   
            //CloudQueueMessage message = new CloudQueueMessage(web.Title);
            CloudQueueMessage message = new CloudQueueMessage(JsonConvert.SerializeObject(list));

            //Add message to queue  
            queue.AddMessageAsync(message);
        }

    }
}
