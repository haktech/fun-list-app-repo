﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECM_ConfidetialLibraryRequestAzFunc
{
    public class QueueMessage
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string libOwnerName { get; set; }
        public string libSiteAdminApprover { get; set; }
        public string Site { get; set; }

    }
}
