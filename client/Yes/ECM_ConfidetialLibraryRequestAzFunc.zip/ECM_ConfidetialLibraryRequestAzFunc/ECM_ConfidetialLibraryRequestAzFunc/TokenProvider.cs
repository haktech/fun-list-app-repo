﻿using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ECM_ConfidetialLibraryRequestAzFunc
{
    public class TokenProvider
    {
        public static async Task<string> GetAccessTokenAsync(string endpoint)
        {
            var clientId = Environment.GetEnvironmentVariable("ClientID");
            var tenantId = Environment.GetEnvironmentVariable("TenantID");
            var certFile = Environment.GetEnvironmentVariable("CertFile");

            var certPassword = Environment.GetEnvironmentVariable("CertPassword");

            using var certificate = GetCertificate(
                Path.Combine(Environment.CurrentDirectory, certFile),
                certPassword);

            var confidentialClient = ConfidentialClientApplicationBuilder
                .Create(clientId)
                .WithTenantId(tenantId)
                .WithCertificate(certificate)
                .Build();

            var token = await confidentialClient
                .AcquireTokenForClient(new[] { $"{endpoint.TrimEnd('/')}/.default" })
                .ExecuteAsync();

            return token.AccessToken;
        }

        private static X509Certificate2 GetCertificate(string path, string password)
        {
            return new X509Certificate2(path, password, X509KeyStorageFlags.MachineKeySet);
        }
    }
}
