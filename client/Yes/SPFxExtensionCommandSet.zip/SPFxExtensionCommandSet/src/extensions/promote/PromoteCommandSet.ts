import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {setup as pnpSetup} from "@pnp/common";
import { sp,Web } from "@pnp/sp/presets/core";
import "@pnp/sp/webs";
import "@pnp/sp/lists/web";
import { IItemAddResult } from "@pnp/sp/items";
import * as React from 'react';
import PromoteDocDialog from './PromoteCommandSetDialog';
import PromoteDocDialogContent from './PromoteCommandSetDialog';
import IPromoteDocDialogContentProps from './PromoteCommandSetDialog';
import * as ReactDOM from 'react-dom';

import {
  BaseListViewCommandSet,
  Command,
  IListViewCommandSetListViewUpdatedParameters,
  IListViewCommandSetExecuteEventParameters,
  RowAccessor
} from '@microsoft/sp-listview-extensibility';
import { Dialog } from '@microsoft/sp-dialog';
import * as strings from 'PromoteCommandSetStrings';

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IPromoteCommandSetProperties {
  // This is an example; replace with your own properties
  sampleTextOne: string;
  sampleTextTwo: string;
}

const LOG_SOURCE: string = 'PromoteCommandSet';

export default class PromoteCommandSet extends BaseListViewCommandSet<IPromoteCommandSetProperties> {

  @override
  public onInit(): Promise<void> {
    Log.info(LOG_SOURCE, 'Initialized PromoteCommandSet');
    //return Promise.resolve();
    return super.onInit().then(_ => {
      //other init code may be present
      pnpSetup({
        spfxContext: this.context
      });
    });
  }

  @override
  public onListViewUpdated(event: IListViewCommandSetListViewUpdatedParameters): void {
    const compareCommandB: Command = this.tryGetCommand('COMMAND_2');
    if (compareCommandB) {
      // This command should be hidden if 0 item selected
      //const listName: string = this.context.pageContext.list.title
      compareCommandB.visible = (event.selectedRows.length === 1 || event.selectedRows.length > 1); 
    }
  }

  @override
  public async onExecute(event: IListViewCommandSetExecuteEventParameters): Promise<void> {
    //const selectedRow: RowAccessor = event.selectedRows[0];
    //var firstname = selectedRow.getValueByName('Title');

    //Get selected file path
    var strArray = [];
    var Ids =[];

    event.selectedRows.forEach((sr) =>
    {
      strArray.push(sr.getValueByName("FileRef"));      
      Ids.push(sr.getValueByName("UniqueId"));
    });
    
    switch (event.itemId) {
      case 'COMMAND_2':
        let dt = new Date();
        const cd : string = dt.getDate() + "/"
                + (dt.getMonth()+1)  + "/" 
                + dt.getFullYear() + " @ "  
                + dt.getHours() + ":"  
                + dt.getMinutes() + ":" 
                + dt.getSeconds();
      //var prs = new  IPromoteDocDialogContentProps({});

      // const dlg  : PromoteDocDialogContent = new PromoteDocDialogContent({

      //   itemID :  Ids.join(";"),
      //   fromSite : this.context.pageContext.web.absoluteUrl,
      //   listName : this.context.pageContext.list.serverRelativeUrl,
      //   rootSiteURL: this.context.pageContext.site.absoluteUrl
      // });

      const element: React.ReactElement<{} > = React.createElement(
        PromoteDocDialogContent,
        {
          itemID: Ids.join(";"),
          fromSite : this.context.pageContext.web.absoluteUrl,
          listName : this.context.pageContext.list.serverRelativeUrl,
          rootSiteURL: this.context.pageContext.site.absoluteUrl
        }
      );

      const div = document.createElement('div');
      ReactDOM.render(element, div);
      
      //  const dialog: PromoteDocDialog = new PromoteDocDialog();
       
      //   dialog.message = 'Promote Document as Record :';
      //   dialog.itemID = Ids.join(";");
      //   dialog.fromSite = this.context.pageContext.web.absoluteUrl;
      //   dialog.listName = this.context.pageContext.list.serverRelativeUrl;
      //   dialog.rootSiteURL = this.context.pageContext.site.absoluteUrl;
      //   dialog.show().then(() => {
      //   });
    
        break;
      default:
        throw new Error('Unknown command');
    }
  }

  }
