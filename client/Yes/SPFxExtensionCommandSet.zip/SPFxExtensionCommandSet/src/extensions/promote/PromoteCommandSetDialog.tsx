import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { BaseDialog, IDialogConfiguration } from '@microsoft/sp-dialog';
import { IFrameDialog } from "@pnp/spfx-controls-react/lib/IFrameDialog";
import { sp } from "@pnp/sp";
import "@pnp/sp/sites";
import { IContextInfo } from "@pnp/sp/sites";
import { IFramePanel } from "@pnp/spfx-controls-react/lib/IFramePanel";

import {
    PrimaryButton,
    ActionButton,
    DialogFooter,
    DialogContent,
    DialogType
} from 'office-ui-fabric-react';

export default interface IPromoteDocDialogContentProps {
    close: () => void;
    itemID: string;
    fromSite: string;
    listName: string;    
    rootSiteURL: string;
}

export default class PromoteDocDialogContent extends React.Component<IPromoteDocDialogContentProps, { hideDialog: boolean, numberOfGuests: number }> {

    constructor(props) {
        super(props);
        this.state = {
            hideDialog: false,
            numberOfGuests: 2
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    private handleChange(event) {
        const target = event.target;
        const value = target.type === 'checkbox' ? target.checked : target.value;
        const name = target.name;

        var partialState = {};
        partialState[name] = value;
        this.setState(partialState);
    }

    private handleSubmit(event) {
        event.preventDefault();
    }
    

    
    public render(): JSX.Element {
        // site = 

      let url = this.props.rootSiteURL + "/SitePages/PromoteRecord.aspx";
        url += "?fromSite=" + this.props.fromSite;
        url += "&docID=" + this.props.itemID;
        url += "&listName=" + this.props.listName;


        return (<IFrameDialog
            url={url}
            //iframeOnLoad={this._onIframeLoaded.bind(this)}
            hidden={this.state.hideDialog}
            onDismiss={()=>{
                console.log('onDismiss');
                this.setState({ hideDialog: true});                
            }}
            modalProps={{
                isBlocking: true
            }}
            dialogContentProps={{
                type: DialogType.close,
                showCloseButton: true
            }}
            width={'800px'}
            height={'600px'}
            iframeOnLoad={iframe => {
                const windowClose = iframe.contentWindow.close;
                const windowClosingEvent = new Event('closeWindow');
                iframe.addEventListener('closeWindow', () => {
                  this.setState({
                    hideDialog: true
                  });
                });
                iframe.contentWindow.close = () => {
                  iframe.dispatchEvent(windowClosingEvent);
                  windowClose();
                };
              }}
            />
            );
            
    }

    //backup ONLY
    // public render(): JSX.Element {
    //     return <DialogContent
    //         title='Promote Document to Record'
    //         onDismiss={this.props.close}
    //         showCloseButton={true}
    //     >
    //         <form>
    //             <label>Files
    //                 <ul>
    //                     {this._files.map((f, i) => {
    //                         console.log("Entered");
    //                         // Return the element. Also pass key     
    //                         return (<li> Url : {f} </li>)
    //                     })}
    //                 </ul>
    //             </label>
    //             <label>
    //                 Is going:
    //                     <input
    //                     name="isGoing"
    //                     type="checkbox"
    //                     checked={this.state.isGoing}
    //                     onChange={this.handleChange} />
    //             </label>
    //             <br />
    //             <label>
    //                 Number of guests:
    //                     <input
    //                     name="numberOfGuests"
    //                     type="number"
    //                     value={this.state.numberOfGuests}
    //                     onChange={this.handleChange} />
    //             </label>
    //         </form>
    //         <DialogFooter>
    //             <Button text='Cancel' title='Cancel' onClick={this.props.close} />
    //             <PrimaryButton text='OK' title='OK' onClick={this.handleSubmit} />
    //         </DialogFooter>
    //     </DialogContent>;
    // }
}

// export default class PromoteDocDialog extends BaseDialog {
//     public message: string;
//     public itemID: string;
//     public fromSite: string;
//     public listName: string;
//     public rootSiteURL: string;
    
//     public render(): void {
//         ReactDOM.render(<PromoteDocDialogContent
//             close={this.close}
//             itemID={this.itemID}
//             fromSite = {this.fromSite}
//             listName = {this.listName}
//             rootSiteURL = {this.rootSiteURL}
//         />, this.domElement);
//     }

//     public getConfig(): IDialogConfiguration {
//         return {
//             isBlocking: false           
//         };
//     }

//     protected onAfterClose(): void {
//         super.onAfterClose();

//         // Clean up the element for the next dialog
//         ReactDOM.unmountComponentAtNode(this.domElement);
//     }
// }
