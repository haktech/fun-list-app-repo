declare interface IPromoteCommandSetStrings {
  Command1: string;
  Command2: string;
}

declare module 'PromoteCommandSetStrings' {
  const strings: IPromoteCommandSetStrings;
  export = strings;
}
