import { WebPartContext } from "@microsoft/sp-webpart-base";
import { ExtensionContext } from '@microsoft/sp-extension-base';

export interface IPromoteRecordProps {
  description: string;
  context: WebPartContext | ExtensionContext;
  SysRecordListPath: string;
  ApproversGroupName: string;
  SysRecordListName: string;
  disciplineMetadataTermsetSource: string[];
  businessMetadataTermSetSource: string[];
}
