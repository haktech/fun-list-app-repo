declare interface IPromoteRecordWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'PromoteRecordWebPartStrings' {
  const strings: IPromoteRecordWebPartStrings;
  export = strings;
}
