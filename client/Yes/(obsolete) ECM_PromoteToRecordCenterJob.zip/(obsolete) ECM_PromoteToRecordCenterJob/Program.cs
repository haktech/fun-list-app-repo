﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using OfficeDevPnP.Core;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using AuthenticationManager = OfficeDevPnP.Core.AuthenticationManager;
using System.IO;
using File = Microsoft.SharePoint.Client.File;
using Microsoft.SharePoint.Client.Taxonomy;
using System.Reflection;
using System.Threading;
using System.Globalization;

namespace PromoteToRecordCenterJob
{
    public static class Program
    {
        public static string siteOwnerGroup = "";
        public static string tenantURL = "";
        // ecm site - store sysRCSites list
        public static string siteURL = "";
        public static string recordCenterURL = "";
        //private static string ECMSandboxURL = "";
        public static string requestListName = "";
        public static string sysRCListName = "";
        public static bool useMoveFile = true;

        public static string camlquery_str = @"
                                            <View><Query>
                                            <Where>
                                            <Eq>
                                            <FieldRef Name='RecordStatus' />
                                            <Value Type = 'Choice' >Approved</Value>
                                            </Eq>
                                            </Where>
                                            </Query></View>";

        static async Task Main(string[] args)
        {
            InitVariables();

            var context = await CreateContext(siteURL);

            // force test item                                    
            //ForceTestWithItemId(context, "https://petronas.sharepoint.com/sites/rc-pdt", 21);
            //return;
            // end force test

            ExecutePromoteToRecordRequests(context);

            //GetPromoteToRecordRequests(context);

            //GetAllFields(clientContext1);

            Console.WriteLine("Job request completed.");
        }

        private static void InitVariables()
        {
            var reader = new AppSettingsReader();

            siteURL = reader.GetValue("SiteURL", typeof(String)) as String;
            //ECMSandboxURL = $"{siteURL}/ecm_sandbox/";
            tenantURL = reader.GetValue("TenantURL", typeof(String)) as String;
            //recordCenterURL = reader.GetValue("RecordCenterURL", typeof(String)) as String;
            requestListName = reader.GetValue("RequestListName", typeof(String)) as String;
            sysRCListName = reader.GetValue("sysRCListName", typeof(String)) as String;
            siteOwnerGroup = reader.GetValue("SiteOwnerGroup", typeof(String)) as String;
            useMoveFile = (bool)reader.GetValue("userMoveFile", typeof(bool));
        }

        private static async Task<ClientContext> CreateContext(string stURL)
        {
            var token = await TokenProvider.GetAccessTokenAsync(new Uri(stURL).GetLeftPart(UriPartial.Authority));

            using var context = new ClientContext(stURL);
            context.ExecutingWebRequest += (sender, e) =>
            {
                e.WebRequestExecutor.RequestHeaders["Authorization"] = "Bearer " + token;
            };

            return context;
        }

        private static void ExecutePromoteToRecordRequests(ClientContext clientContext)
        {
            try
            {
                var sysRCSitesList = clientContext.Web.Lists.GetByTitle(sysRCListName);

                clientContext.Load(sysRCSitesList);
                clientContext.ExecuteQuery();

                var rcItems = sysRCSitesList.GetItems(CamlQuery.CreateAllItemsQuery());
                clientContext.Load(rcItems);
                clientContext.ExecuteQuery();

                if (rcItems.Count > 0)
                {
                    foreach (var rcItem in rcItems)
                    {
                        recordCenterURL = Convert.ToString(rcItem["Title"]);
                        Console.WriteLine("");
                        Console.WriteLine("RecordCenterURL: " + recordCenterURL);

                        if (!string.IsNullOrWhiteSpace(recordCenterURL))
                        {
                            using (var rcContext = clientContext.Clone(recordCenterURL))
                            {

                                #region create site/doc lib

                                //Create Subsite
                                ProvRecordCenter(rcContext, recordCenterURL);

                                //Create Library
                                var items = GetLibrarytoCreate(rcContext, recordCenterURL);

                                foreach (String item in items)
                                {
                                    if (item != "")
                                    {
                                        var temp = item.Replace(recordCenterURL + "/", "").Split('/');
                                        var libSiteURL = recordCenterURL + "/" + temp[0];
                                        Console.WriteLine("LibSiteURL: " + libSiteURL);

                                        ClientContext contextLib = null;

                                        if (TryResolveClientContext(new Uri(libSiteURL), out contextLib, rcContext))
                                        {
                                            using (contextLib)
                                            {
                                                createRecordCenterLibrary(contextLib, item, recordCenterURL);
                                            }
                                        }
                                    }
                                }

                                #endregion

                                GetPromoteToRecordRequests(rcContext, recordCenterURL);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // 
            }

        }

        private static void GetPromoteToRecordRequests(ClientContext clientContext, string URL)
        {
            //clientContext.Load(clientContext.Web);
            //clientContext.ExecuteQuery();
            //Console.WriteLine(clientContext.Web.Title);

            Web oWebsite = clientContext.Web;

            List targetList = oWebsite.Lists.GetByTitle(requestListName);
            clientContext.Load(targetList);
            clientContext.ExecuteQuery();

            // Optioanlly you can use overloaded method CreateAllItemsQuery(int rowlimits, params viewfields): where using "rowlimits" you can limit the number of rows returned and viewfields will return only specified fields in the result set
            // This method will get all the items from all the folders and sub folders including folders and sub folders too
            // CamlQuery oQuery = CamlQuery.CreateAllItemsQuery();
            CamlQuery oQuery = new CamlQuery()
            {
                ViewXml = camlquery_str
            };

            // test zone

            // end test zone

            ListItemCollection oCollection = targetList.GetItems(oQuery);

            clientContext.Load(oCollection);
            clientContext.ExecuteQuery();

            Console.WriteLine("URL: "+ URL);
            Console.WriteLine(oCollection.Count + " item(s) - To Moved");
            Console.WriteLine("");

            foreach (ListItem oItem in oCollection)
            {

                // If status = "Approved" then create the document library
                if (Convert.ToString(oItem["RecordStatus"]) == "Approved")
                {
                    try
                    {
                        Console.WriteLine(oItem["Title"].ToString() + " - To Moved");

                        Console.WriteLine("DocumentSourceURLs: " + Convert.ToString(oItem["DocumentSourceURLs"]));

                        var items = GetItemtoMove(Convert.ToString(oItem["DocumentSourceURLs"]), tenantURL);

                        if (items.Count > 0)
                        {
                            try
                            {
                                MoveDocumentToRecordCenter(clientContext, items, oItem);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);

                            }
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                }
            }
        }
        #region create subsite/doc lib

        private static void ProvRecordCenter(ClientContext clientContext, string rcURL)
        {
            Web oWebsite = clientContext.Web;

            List targetList = oWebsite.Lists.GetByTitle(requestListName);
            clientContext.Load(targetList);
            clientContext.ExecuteQuery();
            CamlQuery oQuery = new CamlQuery()
            {
                ViewXml = camlquery_str
            };
            ListItemCollection oCollection = targetList.GetItems(oQuery);

            clientContext.Load(oCollection);
            clientContext.ExecuteQuery();

            foreach (ListItem oItem in oCollection)
            {
                if (Convert.ToString(oItem["RecordStatus"]) == "Approved")
                {
                    try
                    {
                        //var items = GetItemtoMove(Convert.ToString(oItem["DocumentSourceURLs"]), tenantURL);
                        var documentURL = Convert.ToString(oItem["DocumentSourceURLs"]);
                        //var recordCenterURL = "";

                        if (documentURL.IndexOf($";/sites/") > 0)
                        {
                            // we have more than 1 item to move
                            var temps = documentURL.Split(new[] { $";/sites/" }, StringSplitOptions.RemoveEmptyEntries).ToList();

                            createRecordCenterSite(clientContext, temps[0], rcURL);
                        }
                        else
                        {
                            createRecordCenterSite(clientContext, documentURL, rcURL);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }

        private static string GetRecordCenterSiteUrl(ClientContext context, string documentsPromoted, string rcURL)
        {
            string[] temp = documentsPromoted.Replace("/sites/", "").Split('/');

            //string startUrl = tenantURL + "/sites";
            string recordCenterSiteUrl = "";
            string tempUrl = rcURL + "/" + temp[0];

            if (WebExistsFullUrl(context, tempUrl))
            {
                recordCenterSiteUrl = tempUrl;
            }

            return recordCenterSiteUrl;
        }

        private static List<string> GetLibrarytoCreate(ClientContext clientContext, string rcURL)
        {
            List<string> items = new List<string>();

            Web oWebsite = clientContext.Web;

            List targetList = oWebsite.Lists.GetByTitle(requestListName);
            clientContext.Load(targetList);
            clientContext.ExecuteQuery();
            CamlQuery oQuery = new CamlQuery()
            {
                ViewXml = camlquery_str
            };
            ListItemCollection oCollection = targetList.GetItems(oQuery);

            clientContext.Load(oCollection);
            clientContext.ExecuteQuery();

            foreach (ListItem oItem in oCollection)
            {
                if (Convert.ToString(oItem["RecordStatus"]) == "Approved")
                {
                    var documentURL = Convert.ToString(oItem["DocumentSourceURLs"]);

                    try
                    {
                        if (documentURL.IndexOf($";/sites/") > 0)
                        {
                            var temps = documentURL.Split(new[] { $";/sites/" }, StringSplitOptions.RemoveEmptyEntries).ToList();

                            items.Add(GetRecordCenterSiteLibrary(temps[0], rcURL));
                        }
                        else
                        {
                            items.Add(GetRecordCenterSiteLibrary(documentURL, rcURL));
                        }

                    }
                    catch (Exception ex)
                    {

                    }
                }
            }

            return items;
        }

        private static string GetRecordCenterSiteLibrary(string documentsPromoted, string rcURL)
        {
            string[] temp = documentsPromoted.Replace("/sites/", "").Split('/');

            //string startUrl = tenantURL + "/sites";
            string recordCenterSiteLibrary = "";
            string tempUrl = rcURL + "/" + temp[0];

            if (documentsPromoted.Contains("Confidential") == false)
            {
                string[] library = documentsPromoted.Replace("/sites/" + temp[0] + "/", "").Split('/');
                var newLibraryPath = "";

                foreach (string i in library)
                {
                    if (i == "Correspondence")
                    {
                        break;
                    }
                    if (i == "Administrative")
                    {
                        break;
                    }
                    if (i == "Governance")
                    {
                        break;
                    }
                    if (i == "Reference")
                    {
                        break;
                    }
                    if (i == "Digital Assets")
                    {
                        break;
                    }

                    newLibraryPath += i;
                }

                if (newLibraryPath != "")
                {
                    // Fix created library url - remove '-'
                    //newLibraryPath = newLibraryPath.Replace("-", "");

                    tempUrl = tempUrl + "/" + newLibraryPath;
                    recordCenterSiteLibrary = tempUrl;
                }
            }

            return recordCenterSiteLibrary;
        }

        private static void createRecordCenterSite(ClientContext clientContext, string documentsPromoted, string rcURL)
        {
            var recordCenterURL = "";

            recordCenterURL = GetRecordCenterSiteUrl(clientContext, documentsPromoted, rcURL);

            if (recordCenterURL == "")
            {
                Console.WriteLine("Sub Site creation started - " + recordCenterURL);

                var template = getSiteTemplateCode(clientContext, "blankrecordsite");

                var temp = documentsPromoted.Replace("/sites/", "").Split('/');
                // recordCenterURL = recordCenterURL.Replace(rcURL + "/", "");
                recordCenterURL = temp[0];

                WebCreationInformation oWebCreationInformation = new WebCreationInformation();
                //This is relative URL of the url provided in context
                oWebCreationInformation.Url = recordCenterURL;
                oWebCreationInformation.Title = recordCenterURL;
                oWebCreationInformation.Description = recordCenterURL;

                // This will inherit permission from parent site
                oWebCreationInformation.UseSamePermissionsAsParentSite = true;

                // "STS#0" is the code for 'Team Site' template
                oWebCreationInformation.WebTemplate = template;
                oWebCreationInformation.Language = 1033;

                Web oWeb = clientContext.Site.RootWeb.Webs.Add(oWebCreationInformation);
                oWeb.Navigation.UseShared = true;
                clientContext.ExecuteQuery();
            }
        }

        private static void createRecordCenterLibrary(ClientContext clientContext, string documentsPromoted, string rcURL)
        {
            //    var recordCenterLibraryURL = "";
            Console.WriteLine("Creating library - " + documentsPromoted);


            if (!libraryExistFullUrl(clientContext, documentsPromoted))
            {
                try
                {
                    var temp = documentsPromoted.Replace(rcURL + "/", "").Split('/');
                    var title = temp[1];

                    ListCreationInformation creationInfo = new ListCreationInformation();
                    creationInfo.Title = title;
                    creationInfo.Description = title;
                    creationInfo.TemplateType = (int)ListTemplateType.DocumentLibrary;

                    List newList = clientContext.Web.Lists.Add(creationInfo);
                    clientContext.Load(newList);
                    clientContext.ExecuteQuery();


                    DeleteExistingContentType(clientContext, title);

                    AddContentType(clientContext, title);

                    AddViewColumn(clientContext, title);

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }


        }

        private static void DeleteExistingContentType(ClientContext clientContext, string title)
        {
            using (clientContext)
            {
                List TargetList = null;

                // clientcontext.Web.Lists.GetById - This option also can be used to get the list using List GUID
                // This value is NOT List internal name
                TargetList = clientContext.Web.Lists.GetByTitle(title);
                clientContext.Load(TargetList);

                // Load List conntent types
                clientContext.Load(TargetList.ContentTypes);
                clientContext.ExecuteQuery();

                // Write Content Type name over here
                string contentTypeName = "Document";

                // Get list content types
                ContentTypeCollection contentTypeCollection = TargetList.ContentTypes;

                // Get target content type from list content types
                ContentType targetContentType = (from contentType in contentTypeCollection where contentType.Name == contentTypeName select contentType).FirstOrDefault();

                // Condition to delete target content type.
                if (targetContentType != null)
                {
                    targetContentType.DeleteObject();
                    TargetList.Update();
                    clientContext.ExecuteQuery();
                }
            }
        }

        private static void AddContentType(ClientContext clientContext, string title)
        {
            using (clientContext)
            {
                ContentTypeCollection contentTypeCollection;

                // Option - 1 - Get Content Types from Root web
                contentTypeCollection = clientContext.Site.RootWeb.ContentTypes;

                // Option - 2 - Get Content Types from Current web
                //contentTypeCollection = clientContext.Web.ContentTypes;

                clientContext.Load(contentTypeCollection);
                clientContext.ExecuteQuery();

                // Get the content type from content type collection. Give the content type name over here
                ContentType targetContentType = (from contentType in contentTypeCollection where contentType.Name == "PETRONAS Record" select contentType).FirstOrDefault();

                // Add existing content type on target list. Give target list name over here.
                List targetList = clientContext.Web.Lists.GetByTitle(title);
                targetList.ContentTypes.AddExistingContentType(targetContentType);
                targetList.Update();
                clientContext.Web.Update();
                clientContext.ExecuteQuery();
            }
        }

        private static void AddViewColumn(ClientContext clientContext, string title)
        {
            using (clientContext)
            {
                // clientcontext.Web.Lists.GetById - This option also can be used to get the list using List GUID
                // This value is NOT List internal name
                List targetList = clientContext.Web.Lists.GetByTitle(title);

                // Get required view by specifying view Title here
                View targetView = targetList.Views.GetByTitle("All Documents");

                // Add View column. You can specify Internal or display name of the column over here
                targetView.ViewFields.Add("Approver");
                targetView.ViewFields.Add("Business Metadata");
                targetView.ViewFields.Add("Discipline Metadata");
                //targetView.ViewFields.Add("Declared Record");
                targetView.ViewFields.Add("ECMS Record Type");

                targetView.Update();
                clientContext.ExecuteQuery();
            }
        }

        public static string getSiteTemplateCode(ClientContext clientContext, String templateName)
        {
            string siteTemplateCode = "";


            WebTemplateCollection oWebtTemplateCollection = clientContext.Web.GetAvailableWebTemplates(1033, false);
            clientContext.Load(oWebtTemplateCollection);

            clientContext.ExecuteQuery();

            foreach (WebTemplate oWebTemplate in oWebtTemplateCollection)
            {
                //Console.WriteLine("Template Name: " + oWebTemplate.Name + "  | Template Title: " + oWebTemplate.Title);
                if (oWebTemplate.Title == templateName)
                {
                    siteTemplateCode = oWebTemplate.Name;
                }
            }

            return siteTemplateCode;
        }

        private static bool libraryExistFullUrl(ClientContext context, string libraryFullUrl)
        {
            bool exists = false;

            libraryFullUrl = ReformatURL(libraryFullUrl);

            var folder = context.Web.GetFolderByServerRelativeUrl(libraryFullUrl);
            context.Load(folder, f => f.Exists);

            try
            {
                context.ExecuteQuery();

                if (folder.Exists)
                {
                    //return true;
                    exists = true;
                }

            }
            catch (ServerUnauthorizedAccessException uae)
            {
                Console.WriteLine("You are not allowed to access this folder");
                throw;
            }
            catch (Exception ex)
            {
                //Console.WriteLine("Could not find folder.");
                //return false;
                exists = false;
            }
            return exists;
        }

        #endregion

        private static void MoveDocumentToRecordCenter(ClientContext clientContext, List<string> documentsPromoted, ListItem oItem)
        {
            // https://petronas.sharepoint.com/sites/ECM_Sandbox/Engineering/
            string siteURL = GetSiteUrl(clientContext, documentsPromoted.First());

            // Init siteName & subSiteName

            // string[] temp = siteURL.Replace("https://petronas.sharepoint.com/sites/", "").Split('/');

            string[] temp = siteURL.Replace($"{tenantURL}/sites/", "").Split('/');

            string siteName = temp[0];
            string subSiteName = "Default";
            StringBuilder errorSb = new StringBuilder();

            string destRecordCenterURL = recordCenterURL;

            if (temp.Length > 0)
            {
                destRecordCenterURL = $"{recordCenterURL}/{temp[0]}";
            }

            if (temp.Length > 1)
            {
                subSiteName = temp[1];

                // Fix SPO auto remove '-' upon document library created
                subSiteName = subSiteName.Replace("-", "");

            }

            // Init record center 

            //string recordCenterURL = "";

            //// To make use sharepoint list for mapping later
            //if (temp[0] == "ECM_Sandbox")
            //{
            //    recordCenterURL = ECMSandboxURL;
            //    //"https://petronas.sharepoint.com/sites/recordcenter-test/ecm_sandbox/";
            //}
            //else
            //{
            //    errorSb.AppendLine($"{temp[0]} - Record Center does not map.");
            //}

            //if (string.IsNullOrWhiteSpace(recordCenterURL))
            //    isError = true;


            // Create folder
            List<KeyValuePair<string, string>> oItemParams = null;

            foreach (var documentPromoted in documentsPromoted)
            {
                try
                {
                    // try get taxonomy, if fail then thrown new exception to prevent move file
                    var testT1 = tryParseTaxonomyFieldValue(oItem, "Business_x0020_Metadata");
                    var testT2 = tryParseTaxonomyFieldValue(oItem, "Discipline_x0020_Metadata");
                    var testT3 = tryParseTaxonomyFieldValue(oItem, "ECMS_x0020_Record_x0020_Type");

                    if (testT1 == null || testT2 == null || testT3 == null)
                        throw new ArgumentNullException("TaxonomyFieldValue null");


                    string[] folders = documentPromoted.Replace(siteURL.Replace(tenantURL, ""), "").Split('/');

                    var fullFilePath = $"{tenantURL}{documentPromoted}";

                    Uri uri = new Uri(fullFilePath);
                    string filename = System.IO.Path.GetFileName(uri.LocalPath);

                    oItemParams = new List<KeyValuePair<string, string>>();

                    var (movedItem, iWebURL) = GetOldItemProperties(clientContext, documentPromoted);

                    if (movedItem == null)
                    {
                        errorSb.AppendLine($"{documentPromoted} does not exists.");
                        continue;
                    }

                    var destFolder = "";
                    //string sourceFolder = tenantURL + documentPromoted;

                    Console.WriteLine("Moved file1");

                    using (ClientContext srcContext = clientContext.Clone(destRecordCenterURL))
                    {
                        var sFolderPath = fullFilePath.Replace(iWebURL, "/").Replace(filename, "");

                        var folderUrl = TryCreateDestFolderPath(srcContext, subSiteName, sFolderPath);

                        if (string.IsNullOrWhiteSpace(folderUrl))
                        {
                            errorSb.AppendLine($"Cannot create {sFolderPath} at {srcContext.Url}.");
                            continue;
                        }

                        destFolder = $"{tenantURL}{folderUrl}/{filename}";

                        Console.WriteLine("destFolder: " + destFolder);

                        MoveCopyOptions option = new MoveCopyOptions();
                        option.KeepBoth = false;
                        option.RetainEditorAndModifiedOnMove = true;
                        option.ShouldBypassSharedLocks = true;

                        // MoveCopyUtil.MoveFile(srcContext, fullFilePath, destFolder, false, option);
                        if (useMoveFile)
                        {
                            MoveCopyUtil.MoveFile(srcContext, fullFilePath, destFolder, false, option);
                        }
                        else
                        {
                            // change to copy the file, incase below process fail, we can retry again
                            // if process is success, we will remove it later
                            // option.KeepBoth = false;
                            MoveCopyUtil.CopyFile(srcContext, fullFilePath, destFolder, true, option);
                        }
                        // change to copy the file, incase below process fail, we can retry again
                        // if process is success, we will remove it later
                        //MoveCopyUtil.CopyFile(srcContext, sourceFolder, destFolder, true, option);

                        srcContext.ExecuteQuery();

                        Console.WriteLine(filename + " - Moved");

                        File fileDoc = TryGetFile(srcContext, destFolder.Replace(tenantURL, ""));

                        // Update file properties
                        ListItem item = TryGetListItemByFile(srcContext, destFolder.Replace(tenantURL, ""));

                        if (item == null)
                            continue;

                        List spLst = item.ParentList;
                        srcContext.Load(spLst);
                        srcContext.ExecuteQuery();
                        var fields = spLst.Fields;
                        srcContext.Load(fields);
                        srcContext.ExecuteQuery();

                        TrySetTaxonomyValue(srcContext, oItem, item, "Business_x0020_Metadata", fields);
                        TrySetTaxonomyValue(srcContext, oItem, item, "Discipline_x0020_Metadata", fields);
                        TrySetTaxonomyValue(srcContext, oItem, item, "ECMS_x0020_Record_x0020_Type", fields);

                        item["Document_x0020_Structure"] = oItem["DocumentStructure"];
                        item["Expiry_x0020_Date"] = oItem["ExpiryDate"];
                        item["Security_x0020_Classification"] = oItem["Security_x0020_Classification"];
                        item["Vital_x0020_Classification"] = oItem["VitalClassification"];
                        item["Revision_x0020_No"] = oItem["RevisionNo"];
                        item["DocumentSourceURLs"] = oItem["DocumentSourceURLs"];
                        item["Record_x0020_Status"] = oItem["RecordStatus"];

                        item["Approval_x0020_Date"] = oItem["ApprovalDate"];
                        item["Approver"] = oItem["Approver"];
                        item.Update();
                        srcContext.Load(item);
                        srcContext.ExecuteQuery();

                        // Check in the file
                        srcContext.Load(fileDoc);
                        srcContext.ExecuteQuery();
                        fileDoc.CheckIn("", CheckinType.MajorCheckIn);
                        srcContext.ExecuteQuery();

                        Console.WriteLine(filename + " - Checked in");

                    }

                    var mStatus = UpdateSourceFile(clientContext, documentPromoted, destFolder, movedItem);

                    if (!string.IsNullOrWhiteSpace(mStatus))
                        errorSb.AppendLine(mStatus);

                }
                catch (Exception ex)
                {
                    errorSb.AppendLine($"{documentPromoted} :: {ex.Message}");
                }

            }

            if (oItem != null)
            {
                UpdateRecordStatus(clientContext, oItem.Id, errorSb);
            }
        }

        static public object GetValObjDy(this object obj, string propertyName)
        {
            return obj.GetType().GetProperty(propertyName).GetValue(obj, null);
        }

        private static string GetSiteUrl(ClientContext context, string documentsPromoted)
        {
            string[] temp = documentsPromoted.Replace("/sites/", "").Split('/');

            string startUrl = tenantURL + "/sites";
            string tempSiteUrl = "";
            string tempUrl = "";

            for (int i = 0; i < temp.Length; i++)
            {
                tempUrl += "/" + temp[i];

                if (WebExistsFullUrl(context, startUrl + tempUrl))
                {
                    tempSiteUrl = startUrl + tempUrl;
                }
            }

            return tempSiteUrl;
        }

        private static bool WebExistsFullUrl(ClientContext context, string webFullUrl)
        {
            bool exists = false;
            try
            {
                using (ClientContext testContext = context.Clone(webFullUrl))
                {
                    testContext.Load(testContext.Web, w => w.Title, w => w.Url);
                    testContext.ExecuteQueryRetry();
                    exists = (string.Compare(testContext.Web.Url, webFullUrl, true) == 0);
                }
            }
            catch (Exception ex)
            {
                //if (IsUnableToAccessSiteException(ex) || IsCannotGetSiteException(ex))
                //{
                //    // Site exists, but you don't have access .. not sure if this is really valid
                //    // (I guess if checking if URL is already taken, e.g. want to create a new site
                //    // then this makes sense).
                //    exists = true;
                //}
            }
            return exists;
        }

        private static bool IsCannotGetSiteException(Exception ex)
        {
            throw new NotImplementedException();
        }

        private static bool IsUnableToAccessSiteException(Exception ex)
        {
            throw new NotImplementedException();
        }

        private static void TrySetTaxonomyValue(ClientContext ctx, ListItem oItem, ListItem nItem, string fieldName, FieldCollection fields)
        {
            var g1 = fields.Where(x => x.InternalName == fieldName).FirstOrDefault();

            if (g1 == null)
                return;

            var t1 = tryParseTaxonomyFieldValue(oItem, fieldName);

            if (t1 != null)
            {
                nItem.SetTaxonomyFieldValue(g1.Id, t1.Label, Guid.Parse(t1.TermGuid));
            }
            else
            {
                throw new ArgumentNullException("TaxonomyFieldValue null");
            }
        }

        private static TaxonomyFieldValue tryParseTaxonomyFieldValue(ListItem item, string fieldName)
        {
            if (item == null)
                throw new ArgumentNullException("item");

            TaxonomyFieldValue t1 = item[fieldName] as TaxonomyFieldValue;

            if (t1 != null)
            {
                return t1;
            }

            Dictionary<string, object> t2 = item[fieldName] as Dictionary<string, object>;
            if (t2 != null)
            {
                return ConvertDictionaryToTaxonomyFieldValue(t2);
            }

            return null;
        }

        private static TaxonomyFieldValue ConvertDictionaryToTaxonomyFieldValue(Dictionary<string, object> dictionary)
        {
            try
            {
                string ObjectType = "_ObjectType_";
                if (!dictionary.ContainsKey(ObjectType) || !dictionary[ObjectType].Equals("SP.Taxonomy.TaxonomyFieldValue"))
                {
                    throw new InvalidOperationException("Dictionary value represents no TaxonomyFieldValue.");
                }

                return new TaxonomyFieldValue
                {
                    Label = dictionary["Label"].ToString(),
                    TermGuid = dictionary["TermGuid"].ToString(),
                    WssId = int.Parse(dictionary["WssId"].ToString(), CultureInfo.InvariantCulture)
                };
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        private static void TrySetTaxonomyValue(ClientContext ctx, ListItem item, TaxonomyFieldValue tfv, string fieldName)
        {
            List spLst = item.ParentList;
            ctx.Load(spLst);
            ctx.ExecuteQuery();
            var fields = spLst.Fields;
            ctx.Load(fields);
            ctx.ExecuteQuery();
            Field keywordField = spLst.Fields.GetByInternalNameOrTitle(fieldName);

            ctx.Load(keywordField);
            ctx.ExecuteQuery();

            TaxonomyField taxonomyField = ctx.CastTo<TaxonomyField>(keywordField);


            taxonomyField.SetFieldValueByValue(item, tfv);
            //taxonomyField.SetFieldValueByValue(item, fromTx);
        }

        private static File TryGetFile(ClientContext ctx, string filePath)
        {

            try
            {
                File fileDoc = ctx.Web.GetFileByServerRelativeUrl(filePath.Replace(tenantURL, ""));
                ctx.Load(fileDoc, f => f.Exists, f => f.CheckOutType);
                ctx.ExecuteQuery();
                return fileDoc;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"TryGetFile Error:: {ex.Message}");
            }
            return null;
        }

        private static Term TryGetTermByID(ClientContext clientContext, Guid termId)
        {
            try
            {

                TaxonomySession taxonomySession = TaxonomySession.GetTaxonomySession(clientContext);
                TermStore termStore = taxonomySession.GetDefaultSiteCollectionTermStore();
                var temp = termStore.GetTerm(termId);
                clientContext.Load(temp);
                clientContext.ExecuteQuery();

                return temp;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }

        private static TaxonomyFieldValue CloneTaxonomyFieldValue(TaxonomyFieldValue tfv)
        {
            return new TaxonomyFieldValue()
            {

                Label = tfv.Label,
                TermGuid = tfv.TermGuid,
                WssId = -1,

            };
        }

        private static ListItem TryGetListItemByFile(ClientContext ctx, string filePath)
        {

            try
            {
                File fileDoc = ctx.Web.GetFileByServerRelativeUrl(filePath.Replace(tenantURL, ""));
                ListItem item = fileDoc.ListItemAllFields;
                ctx.Load(item);
                ctx.Load(item.ParentList);
                ctx.Load(item.File);
                ctx.ExecuteQuery();
                return item;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"TryGetListItemByFile Error:: {ex.Message}");

            }
            return null;
        }


        private static (ListItem, string) GetOldItemProperties(ClientContext clientContext, string srcFile)
        {
            //  var subSiteUrl = GetSourceSiteURL(srcFile);
            var data = new List<KeyValuePair<string, string>>(); ;

            try
            {
                ClientContext srcContext;
                var url = $"{tenantURL}{srcFile}";
                if (srcFile.IndexOf(tenantURL) >= 0)
                    url = srcFile;

                if (!TryResolveClientContext(new Uri(url), out srcContext, clientContext))
                {
                    return (null, null);
                }

                using (srcContext)
                {
                    return (TryGetListItemByFile(srcContext, srcFile), srcContext.Url);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static string GetSourceSiteURL(string document)
        {
            string sourceFile = tenantURL + document;

            string[] temp = document.Trim().Split('/');

            string siteName = temp[2]; //ECM
            string subSiteName = temp[3]; //GTS
            string libName = temp[4]; // Administrative
            string folderName01 = temp[5]; // Folder A
            string fileName = temp[temp.Length - 1]; // last row

            return tenantURL + "/sites/" + siteName + "/" + subSiteName;
        }

        private static string UpdateSourceFile(ClientContext clientContext, string documentsPromoted, string destFile, ListItem oItem)
        {
            //string dstUrl = "https://cysolutionmy.sharepoint.com/sites/recordcenter/Record%20GTS/";

            // https://cysolutionmy.sharepoint.com/sites/ECM/GTS/Administrative/

            // tenantURL + documentsPromoted
            // https://cysolutionmy.sharepoint.com/sites/ECM/GTS/Administrative/ECM - Metadata Mapping V1.1 (1).xlsx

            // documentsPromoted
            // /sites/ECM/GTS/Administrative/ECM - Metadata Mapping V1.1 (1).xlsx

            string sourceFile = tenantURL + documentsPromoted;

            string[] temp = documentsPromoted.Trim().Split('/');

            //string siteName = temp[2]; //ECM
            //string subSiteName = temp[3]; //GTS
            //string libName = temp[4]; // Administrative
            //string folderName01 = temp[5]; // Folder A
            string fileName = temp[temp.Length - 1]; // last row

            //string subSiteURL = tenantURL + "/sites/" + siteName + "/" + subSiteName;


            ClientContext srcContext;

            if (!TryResolveClientContext(new Uri(sourceFile), out srcContext, clientContext))
            {
                return $"UpdateSourceFile::Cannot find ClientContext for {sourceFile}";
            }

            // Create link in source folder to dest file
            using (srcContext)
            {
                var lib = srcContext.Web.GetListById(oItem.ParentList.Id);
                srcContext.Load(lib);
                srcContext.ExecuteQuery();

                FileCreationInformation itemCreateInfo = new FileCreationInformation();
                itemCreateInfo.Overwrite = true;
                itemCreateInfo.Url = fileName + ".url";
                itemCreateInfo.Content = Encoding.ASCII.GetBytes("[InternetShortcut]URL = " + destFile);

                // Folder newFolder = lib.RootFolder;
                var tempPath = documentsPromoted.Replace(fileName, "");
                Folder newFolder = srcContext.Web.GetFolderByServerRelativeUrl(tempPath);
                //for (int i = temp.Length - 2; i < temp.Length - 1; i++)
                //{
                //    string folderName = temp[i];

                //    newFolder = newFolder.ResolveSubFolder(folderName.Replace("%20", " "));
                //}

                //var newItem = lib.RootFolder.ResolveSubFolder(folders).Files.Add(itemCreateInfo);

                var newItem = newFolder.Files.Add(itemCreateInfo);
                srcContext.Load(newItem);
                srcContext.ExecuteQuery();

                // todo: set item properties to original

                var _FileItem = newItem.ListItemAllFields;
                _FileItem["Title"] = oItem["Title"];
                if (_FileItem.FieldValues.Any(x => x.Key == "Security_x0020_Classification"))
                {
                    _FileItem["Security_x0020_Classification"] = oItem["Security_x0020_Classification"];
                }

                if (_FileItem.FieldValues.Any(x => x.Key == "Vital_x0020_Classification"))
                {
                    _FileItem["Vital_x0020_Classification"] = oItem["Vital_x0020_Classification"];
                }

                if (_FileItem.FieldValues.Any(x => x.Key == "Business_x0020_GTS"))
                {
                    _FileItem["Business_x0020_GTS"] = oItem["Business_x0020_GTS"];
                }

                if (_FileItem.FieldValues.Any(x => x.Key == "Domain_x0020_GTS"))
                {
                    _FileItem["Domain_x0020_GTS"] = oItem["Domain_x0020_GTS"];
                }

                _FileItem["Created"] = oItem["Created"];
                _FileItem["Modified"] = oItem["Modified"];
                _FileItem["Author"] = oItem["Author"];
                _FileItem["Editor"] = oItem["Editor"];

                FieldUrlValue u = new FieldUrlValue();
                u.Url = destFile;
                u.Description = "Moved to record center";
                _FileItem["_ShortcutUrl"] = u;
                _FileItem.Update();

                srcContext.ExecuteQuery();
                Console.WriteLine("Source linked");

                if (!useMoveFile)
                {
                    // clean up file
                    try
                    {
                        File f1 = srcContext.Web.GetFileByServerRelativeUrl(oItem.File.ServerRelativeUrl);
                        if (f1 != null)
                        {
                            f1.DeleteObject();
                            srcContext.ExecuteQuery();
                        }
                    }
                    catch (Exception ex)
                    {
                        return ex.Message;
                    }
                }

                return string.Empty;
            }
        }

        private static void UpdateRecordStatus(ClientContext clientContext, int ID, StringBuilder sb)
        {
            using (clientContext)
            {
                // This value is NOT List internal name
                List targetList = clientContext.Web.Lists.GetByTitle(requestListName);

                // Get Item by ID
                ListItem oItem = targetList.GetItemById(ID);

                // Update status


                if (sb.Length > 0)
                {
                    oItem["RecordStatus"] = "Error";
                }
                else
                {
                    oItem["RecordStatus"] = "Completed";
                }

                oItem["Remarks"] = sb.ToString();

                //// Update Manage groups
                //FieldUrlValue url = new FieldUrlValue();
                //url.Url = siteURL + "/_layouts/15/user.aspx?List=" + docLibList.Id;
                //url.Description = "Manage Users";
                //oItem["ManageGroups"] = url;

                oItem.Update();
                clientContext.ExecuteQuery();

                Console.WriteLine("Record updated to Promoted");
            }
        }

        private static List<string> GetItemtoMove(string documentURL, string tenantURL)
        {
            List<string> items = new List<string>();

            if (string.IsNullOrWhiteSpace(documentURL))
                return items;

            if (documentURL.IndexOf($";/sites/") > 0)
            {
                // we have more than 1 item to move
                var temps = documentURL.Split(new[] { $";/sites/" }, StringSplitOptions.RemoveEmptyEntries).ToList();

                foreach (var temp in temps)
                {
                    var item = temp;
                    if (temp.EndsWith(".url"))
                        continue;

                    if (!temp.StartsWith("/sites/"))
                        item = $"/sites/{temp}";

                    items.Add(item);
                }
                // items.AddRange(temps.Where(x => !x.EndsWith(".url")).ToList());
            }
            else
            {
                items.Add(documentURL);
            }

            return items;
        }

        public static bool TryResolveClientContext(Uri requestUri, out ClientContext context, ClientContext fContext)
        {
            context = null;
            var baseUrl = requestUri.GetLeftPart(UriPartial.Authority);
            for (int i = requestUri.Segments.Length; i >= 0; i--)
            {
                var path = string.Join(string.Empty, requestUri.Segments.Take(i));
                string url = string.Format("{0}{1}", baseUrl, path);
                try
                {
                    context = fContext.Clone(url);
                    context.ExecuteQuery();
                    return true;
                }
                catch (Exception ex) { }
            }
            return false;
        }

        public static string ReformatURL(string urlOri)
        {
            // https://petronas.sharepoint.com/sites/rc-upstream/ecm_sabah/SHR-PPlngMgmt

            var temp = urlOri.Replace("https://petronas.sharepoint.com/sites/", "").Split('/');

            var newText = temp[temp.Length - 1].Replace("-", "");

            var newUrl = "";

            for (var i = 0; i < temp.Length - 1; i++)
            {
                newUrl += temp[i] + "/";
            }

            return newUrl + newText;
        }

        public static string TryCreateDestFolderPath(ClientContext distContext, string listName, string tempPath)
        {
            try
            {
                Console.WriteLine("running TryCreateDestFolderPath");
                //if (listName == "FEE")
                //    listName = "Front End Engineering";

                var folders = tempPath.Split('/');


                var folder = distContext.Web.EnsureFolderPath($"/{listName}{tempPath}");

                distContext.Load(folder);
                distContext.ExecuteQuery();
                Thread.Sleep(1000);


                var isExists = distContext.Web.DoesFolderExists(folder.ServerRelativeUrl);

                //Console.WriteLine("folder.ServerRelativeUrl: " + folder.ServerRelativeUrl);

                //Console.WriteLine("isExists: " + isExists);

                if (!isExists)
                {
                    Console.WriteLine($"TryCreateDestFolderPath::{folder.ServerRelativeUrl} fail.Retry");

                    var folderR1 = distContext.Web.EnsureFolderPath($"/{listName}{tempPath}");
                    distContext.Load(folderR1);
                    distContext.ExecuteQuery();
                }

                var folder1 = distContext.Web.GetFolderByServerRelativePath(ResourcePath.FromDecodedUrl(folder.ServerRelativeUrl));

                distContext.Load(folder1);
                distContext.ExecuteQuery();

                return folder1.ServerRelativeUrl;
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }
            return string.Empty;
        }

        private static void ForceTestWithItemId(ClientContext ctx, string rcURL, int itemId)
        {
            using (var rcContext = ctx.Clone(rcURL))
            {
                var oWebsite = rcContext.Web;
                List targetList = oWebsite.Lists.GetByTitle(requestListName);
                var oItem = targetList.GetItemById(itemId);

                rcContext.Load(oItem);
                rcContext.ExecuteQuery();

                var items = GetItemtoMove(Convert.ToString(oItem["DocumentSourceURLs"]), tenantURL);

                if (items.Count > 0)
                {
                    try
                    {
                        recordCenterURL = rcURL;
                        MoveDocumentToRecordCenter(rcContext, items, oItem);
                        // RecoverMoveDocumentToRecordCenter(rcContext, items, oItem);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);

                    }
                }

            }
        }
    }
}
